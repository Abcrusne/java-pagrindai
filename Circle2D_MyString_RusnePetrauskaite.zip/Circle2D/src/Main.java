
public class Main {

	public static void main(String[] args) {
		Circle2D c1 = new Circle2D(1, 2, 5);
		Circle2D c2 = new Circle2D(2, 2, 1);

		System.out.println(c1.contains(3, 2));
		System.out.println(c1.contains(c2));
		System.out.println(c1.overlaps(c2));
	}
}


public class Circle2D {

	private double x;
	private double y;
	private int radius;

	public Circle2D() {
		this.x = 0;
		this.y = 0;
		this.radius = 1;
	}

	public Circle2D(double x, double y, int radius) {
		this.x = x;
		this.y = y;
		this.radius = radius;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public double getArea() {
		return radius * radius * Math.PI;
	}

	public double getPerimeter() {
		return 2 * radius * Math.PI;
	}

	public boolean contains(double x, double y) {
		double distance = Math.sqrt((Math.pow(this.x - x, 2)) + (Math.pow(this.y - y, 2)));
		if (distance <= radius * 2) {
			return true;
		} else {
			return false;
		}
	}

	public boolean contains(Circle2D circle) {
		double distance = Math.sqrt((Math.pow(circle.getX() - x, 2)) + (Math.pow(circle.getY() - y, 2)));
		if (distance <= (this.radius - circle.radius)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean overlaps(Circle2D circle) {
		double distance = Math.sqrt((Math.pow(circle.getX() - x, 2)) + (Math.pow(circle.getY() - y, 2)));
		if (distance <= Math.abs((this.radius - circle.radius)) && distance <= (this.radius + circle.radius)) {
			return true;
		} else {
			return false;
		}
	}

}

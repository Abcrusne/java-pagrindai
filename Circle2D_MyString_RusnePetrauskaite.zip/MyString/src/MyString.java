
public class MyString {

	private char[] chars;
	private String s;

	public MyString() {

	}

	public MyString(String s) {

	}

	public MyString(char[] chars) {
		this.chars = chars;
	}

	public char charAt(int index) {
		return charAt(index);
	}

	public int length() {
		return chars.length;
	}

	public MyString substring(int begin, int end) {
		MyString newStr = new MyString();
		return newStr.substring(begin, end);
	}

	public MyString toLowerCase() {
		MyString newStr = new MyString();
		return newStr.toLowerCase();
	}

	public boolean equals(MyString s) {
		MyString str = (MyString) s;
		return this.chars.equals(str.chars);
	}

	public static MyString valueOf(int i) {
		MyString newStr = new MyString();
		return newStr.valueOf(i);
	}

	public int compare(String s) {
		return s.compareTo(s);
	}

	public MyString substring(int begin) {
		MyString newStr = new MyString();
		return newStr.substring(begin);
	}

	public MyString toUpperCase() {
		MyString newStr = new MyString();
		return newStr.toUpperCase();
	}

	public char[] toChars() {
		String s = "";
		char[] chars = s.toCharArray();
		return chars;
	}

	public static MyString valueOf(boolean b) {
		MyString newStr = new MyString();
		return newStr.valueOf(b);
	}

}

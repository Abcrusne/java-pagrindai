
public class Main {
	public static void main(String[] args) {

		Greeter lt1 = new Greeter("Petras");
		lt1.greet(new LithuanianGreetingStrategy());
		lt1.greet(new LithuanianGreetingStrategyOne());
		lt1.greet(new LithuanianGreetingStrategyTwo());
		System.out.println("----");

		Greeter en = new Greeter("Ann");
		en.greet(new EnglishGreetingStrategy());
		en.greet(new EnglishGreetingStrategyOne());
		en.greet(new EnglishGreetingStrategyTwo());

	}
}

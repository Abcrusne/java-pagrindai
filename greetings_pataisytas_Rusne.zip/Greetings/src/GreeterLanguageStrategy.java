
interface GreeterLanguageStrategy {

	void getGreetingString(String name);

}

class LithuanianGreetingStrategy implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Labas %s", name + "."));

	}

}

class LithuanianGreetingStrategyOne implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Labas %s", name + "!"));

	}

}

class LithuanianGreetingStrategyTwo implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Labas %s", name + "!!!"));

	}

}

class EnglishGreetingStrategy implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Hello %s", name + "."));

	}
}

class EnglishGreetingStrategyOne implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Hello %s", name + "!"));

	}
}

class EnglishGreetingStrategyTwo implements GreeterLanguageStrategy {

	public void getGreetingString(String name) {
		System.out.println(String.format("Hello %s", name + "!!!"));

	}
}
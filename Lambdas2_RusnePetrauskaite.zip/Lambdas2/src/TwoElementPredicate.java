
public interface TwoElementPredicate<T> {

	boolean betterEntry(T t1, T t2);

}


public class ElementUtils<T> {
//
//	public interface TwoElementPredicate<T> {
//
//		boolean betterEntry(T t1, T t2);

	public static <T> T isBetterEntry(T t1, T t2, TwoElementPredicate<T> name) {
		if (name.betterEntry(t1, t2)) {
			return t1;
		}
		return t2;

	}
}

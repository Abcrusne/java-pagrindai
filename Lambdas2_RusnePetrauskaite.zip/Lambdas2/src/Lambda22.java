public class Lambda22 {

	public static void main(String[] args) {
		String string1 = "aa";
		String string2 = "ccc";

		int num1 = 150;
		int num2 = 2;
		String longer = ElementUtils.isBetterEntry(string1, string2, (s1, s2) -> s1.length() > s2.length());
		System.out.println(longer);

		String first = ElementUtils.isBetterEntry(string1, string2, (s1, s2) -> true);
		System.out.println(first);
		ElementUtils.isBetterEntry(string1, string2, (s1, s2) -> s1.length() > s2.length());

		Integer longe = ElementUtils.isBetterEntry(num1, num2, (s1, s2) -> s1.SIZE > s2.SIZE);
		System.out.println(longe);

		Integer firs = ElementUtils.isBetterEntry(num1, num2, (s1, s2) -> true);
		System.out.println(firs);

//		ElementUtils.betterEntry(car1, car2, (c1, c2) -> c1.getPrice() > c2.getPrice());
//		ElementUtils.betterEntry(employee1, employee2, (e1, e2) -> e1.getSalary() > e2.getSalary());

//		TwoStringPredicate TwoStringPredicate = (s1, s2) ->  s1.compareTo(s2);
//		TwoStringPredicate.betterString("abc", "zzzzzz");

		// TwoStringPredicate<String> string1 = ;

//		Comparator<String> stringComparatorLambda = ( s1,  s2) -> s1.compareTo(s2);
//				int lambdaComparison =stringComparatorLambda.compare("hey", "hello");
//				System.out.println(lambdaComparison);
	}

}

import java.util.Arrays;

public class Main {

	public static void main(final String... args) {

		final String[] strings = new String[] { "alpha", "bravo", "charlie", "delta", "echo", "foxtrot", "E00", "E1",
				"mmeeemm" };
		System.out.println("original: " + Arrays.toString(strings));

		// shortest to longest
		Arrays.sort(strings, (a, b) -> a.length() - b.length());
		System.out.println("sorted: " + Arrays.asList(strings));

		// reverse
		Arrays.sort(strings, (a, b) -> b.length() - a.length());
		System.out.println("sorted: " + Arrays.asList(strings));

		// alphabetically
		Arrays.sort(strings, (a, b) -> a.charAt(0) - b.charAt(0));
		System.out.printf("sorted: %s%n", Arrays.asList(strings));

		// sort if contains E - first
		Arrays.sort(strings, (a, b) -> (a.contains("e")) ? -1 : +1);
		System.out.println("sorted: " + Arrays.asList(strings));

		// sort if contains E - first - static method
		Arrays.sort(strings, SortUtils.containsE());
		System.out.println("sorted: " + Arrays.asList(strings));
	}
}

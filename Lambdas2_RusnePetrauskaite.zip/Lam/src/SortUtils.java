import java.util.Comparator;

public class SortUtils {

	public static Comparator<String> containsE() {
		return (a, b) -> (a.contains("e")) ? -1 : +1;
	}
}

package lt.vtmc.Rusne;

import com.eisgroup.javaexam.factory.Color;
import com.eisgroup.javaexam.factory.Transportation;

public class Transport extends Transportation {
	private String make;
	private String model;
	private double price;
	private Color color;
	private double length;

	public Transport(String make, String model, double price, Color color) {
		super(make, model, price, color);
		this.make = make;
		this.model = model;
		this.price = price;
		this.color = color;
	}

	public Transport(String make, String model, double price, Color color, double length) {
		super(make, model, price, color);
		this.make = make;
		this.model = model;
		this.price = price;
		this.color = color;
		this.length = length;
	}

	public java.lang.String getMake() {
		return this.make;
	}

	public java.lang.String getModel() {
		return this.model;
	}

	@Override
	public double getFinalPrice() {

		return (0.21 * this.price) + this.price;
	}

	public Color getColor() {
		return this.color;

	}

	public double getPrice() {
		return this.price;
	}

	public double getLength() {
		return this.length;
	}

}

package lt.vtmc.Rusne;

import com.eisgroup.javaexam.factory.TransportationFactory;
import com.eisgroup.javaexam.factory.test.BaseTransportationFactoryTest;

public class BaseTransportationFactory extends BaseTransportationFactoryTest {

	@Override
	protected TransportationFactory getTransportationFactory() {

		return new TransportationFactoryImpl();
	}

//	public void bothTransportationAreOfDifferentTypes() {
//	}

}

package lt.vtmc.Rusne;

import com.eisgroup.javaexam.factory.Color;

public class Car extends Transport {

	public Car(String make, String model, double price, Color color) {
		super(make, model, price, color);
		// TODO Auto-generated constructor stub
	}

}

package lt.vtmc.Rusne;

import com.eisgroup.javaexam.factory.Color;
import com.eisgroup.javaexam.factory.Transportation;
import com.eisgroup.javaexam.factory.TransportationFactory;

public class TransportationFactoryImpl implements TransportationFactory {

	public Transportation produceBoat(java.lang.String make, java.lang.String model, double price, Color color,
			double length) {
		Boat boat = null;
		switch (color) {
		case BLACK:
			boat = new Boat(make, model, price, color.BLACK, length);
			break;
		case WHITE:
			boat = new Boat(make, model, price, color.WHITE, length);
			break;

		case RED:
			boat = new Boat(make, model, price, color.RED, length);
			break;

		case YELLOW:
			boat = new Boat(make, model, price, color.YELLOW, length);
			break;

		case BLUE:
			boat = new Boat(make, model, price, color.BLUE, length);
			break;
		}

		return boat;

	}

	public Transportation produceCar(java.lang.String make, java.lang.String model, double price, Color color) {

		Car car = null;
		switch (color) {
		case BLACK:
			car = new Car(make, model, price, color.BLACK);
			break;
		case WHITE:
			car = new Car(make, model, price, color.WHITE);
			break;

		case RED:
			car = new Car(make, model, price, color.RED);
			break;

		case YELLOW:
			car = new Car(make, model, price, color.YELLOW);
			break;

		case BLUE:
			car = new Car(make, model, price, color.BLUE);
			break;
		}

		return car;
	}

}

//if ("BOAT".equalsIgnoreCase(model)) {
//return new Transport(make, model, price, color, length);
//}
//if ("CAR".equalsIgnoreCase(model)) {
//return new Transport(make, model, price, color);
//}
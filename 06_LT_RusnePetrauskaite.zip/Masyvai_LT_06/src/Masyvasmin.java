// find max and min values of given array
//  find index of min value. find index of max value.
public class Masyvasmin {
	public static void main(String[] args) {
		int[] array = new int[] { 16, 2, 3, 4, 5, 6, 11, 4, 20 };
		int max = getMax(array);
		System.out.println("Max: " + max);
		int min = getMin(array);
		System.out.println("Min: " + min);
		getMinIndex(array);
		getMaxIndex(array);

	}

	public static int getMax(int[] inputArray) {
		int maxValue = inputArray[0];
		for (int i = 1; i < inputArray.length; i++) {
			if (inputArray[i] > maxValue) {
				maxValue = inputArray[i];
			}
		}
		return maxValue;
	}

	public static int getMin(int[] inputArray) {
		int minValue = inputArray[0];
		for (int i = 1; i < inputArray.length; i++) {
			if (inputArray[i] < minValue) {
				minValue = inputArray[i];
			}
		}
		return minValue;
	}

	public static void getMinIndex(int[] inputArray) {
		int minValue = getMin(inputArray);
		for (int j = 0; j < inputArray.length; j++) {
			if (minValue == inputArray[j]) {
				System.out.println(minValue + " is at index " + j);
			}
		}
	}

	public static void getMaxIndex(int[] inputArray) {
		int maxValue = getMax(inputArray);
		for (int j = 0; j < inputArray.length; j++) {
			if (maxValue == inputArray[j]) {
				System.out.println(maxValue + " is at index " + j);
			}
		}
	}
}

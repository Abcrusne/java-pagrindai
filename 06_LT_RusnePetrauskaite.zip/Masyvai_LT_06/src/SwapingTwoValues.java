
public class SwapingTwoValues {
	public static void main(String[] argv) {
		int x = 2;
		int y = 3;
		System.out.println("Before: " + x + ", " + y);
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("After: " + x + ", " + y);
	}
}

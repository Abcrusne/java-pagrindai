
// write method which generates random values of array (but size of 
//array is given, random number interval is given too (min &max);
// write a method for printing generated array
import java.util.Random;

public class Masyvai {
	public static void main(String[] args) {
		generateRandomArray(5, 1, 10);
		printArray();
	}

	public static int[] generateRandomArray(int size, int min, int max) {
		int[] array = new int[size];
//			between intervals min and max Math random
		Random random = new Random();
		int rand = 0;
		for (int i = 0; i < array.length; i++) {
			while (i < array.length) {
				array[i] = random.nextInt(max - min) + min;
//				System.out.println(array[i]);
				break;
			}
		}
		return array;
	}

	public static void printArray() {
		int[] arrayNew = generateRandomArray(5, 1, 10);
		for (int i = 0; i < arrayNew.length; i++)
			System.out.println(arrayNew[i]);
	}
}

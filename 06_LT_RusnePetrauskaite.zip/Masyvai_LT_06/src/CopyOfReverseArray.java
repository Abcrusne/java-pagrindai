import java.util.Arrays;

public class CopyOfReverseArray {

	public static void copy(int[] array, int size) {
		int[] copyArray = new int[size];
		int s = size;
		for (int i = 0; i < size; i++) {
			copyArray[s - 1] = array[i];
			s--;
		}
		System.out.println("Reversed array: ");
		for (int j = 0; j < size; j++) {
			System.out.println(copyArray[j]);
//			System.out.println("Reversed array: " + Arrays.toString(copyArray));
		}
	}

	public static void main(String[] args) {
		int[] array = new int[] { 1, 2, 11, 4, 7 };
		System.out.println("Original array: " + Arrays.toString(array));
		copy(array, array.length);
	}
//	public static void main(String[] args) {
//		int[] array = new int[] { 1, 2, 6, 7, 5 };
//		System.out.println("Original array: " + Arrays.toString(array));
//		System.out.println("Reversed array: ");
//		for (int i = array.length - 1; i >= 0; i--)
//			System.out.print(array[i]);
//	}
}

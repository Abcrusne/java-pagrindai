import java.util.Arrays;

// remove k element from array and rewrite new array and print it
public class RemoveElementFromArray {

	public static int[] remove(int[] array, int k) {
//		System.out.println("Original array: " + Arrays.toString(array));
//		create new array
		int[] newArray = new int[array.length - 1];
//		copy all elements from array
		for (int i = 0, j = 0; i < array.length; i++) {
			if (i == k) {
				continue;
			}
			newArray[j++] = array[i];
		}
		return newArray;
	}

	public static void main(String[] args) {
		int[] array = new int[] { 1, 2, 3, 4, 5 };
		System.out.println("Original array: " + Arrays.toString(array));
		remove(array, 1);
		int[] cop = remove(array, 1);
		System.out.println("Removed index array: " + Arrays.toString(cop));

	}
}

public class FizzBazz {
	public static void main(String[] args) {
		for (int i = 1; i <= 20; i++) {
			if (i % 15 == 0) {
				System.out.println("bimbam");
			} else if (i % 3 == 0) {
				System.out.println("bim");
			} else if (i % 5 == 0) {
				System.out.println("bam");
			} else {
				System.out.println(String.valueOf(i));
			}
		}
	}
}
//	public static void main(String[] args) {
//		int[] array; // declare an array of integers
//
//		array = new int[21]; // create an array of integers
//
//		// assign a value to each array element and print
//		for (int i = 1; i < array.length; i++) {
//			array[i] = i;
//			System.out.print(array[i] + " ");
//		}
//		System.out.println();
//	}
//}
//	public static void main(String[] args) {
//		generateArrayFizzBuzz();
//	}
//
//	public static int generateArrayFizzBuzz() {
//		int[] array = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
//		for (int i = 0; i < array.length; i++) {
//			if (array[i] % 3 == 0) {
//					if (array[i] % 5 == 0){
//						return "bimbam";
//				}else {
//					return "bim";
//				}
//				
//			} else if (array[i] % 5 == 0) {
//				return "bam";
//			}
//			System.out.println(array[i]);
//		}
//		return array;
//	}
////		int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
////		for (int element : arr) {
////			if (element % 3 == 0) {
////				System.out.println("bim");
////			} else if (element % 5 == 0) {
////				System.out.println("bam");
////			} else if (element % 3 == 0 && element % 5 == 0) {
////				System.out.println("bimabam");
////			} else {
//
////	public static void printArray() {
////		int[] arrayNew = generateArrayFizzBuzz();
////		for (int i = 0; i < arrayNew.length; i++)
////			System.out.println(arrayNew[i]);
//}

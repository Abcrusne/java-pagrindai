import java.util.Arrays;

public class ReverseGivenArray {
	public static int[] copy(int[] array, int size) {
		int[] copyArray = new int[size];
		int[] arr = new int[size];
		int s = size;
		for (int i = 0; i < size; i++) {
			copyArray[s - 1] = array[i];
			s--;
		}
		for (int j = 0; j < size; j++) {
			arr[j] = copyArray[j];
		}
		return arr;
	}

	public static void main(String[] args) {
		int[] array = new int[] { 1, 2, 11, 4, 7 };
		System.out.println("Original array: " + Arrays.toString(array));
		int[] copy = copy(array, array.length);
		System.out.println("Reversed: " + Arrays.toString(copy));
	}
}

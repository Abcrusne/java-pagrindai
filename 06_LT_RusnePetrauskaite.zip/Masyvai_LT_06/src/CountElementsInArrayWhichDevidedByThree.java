// count how many elements are in array which 
// divides by 3.
public class CountElementsInArrayWhichDevidedByThree {
	public static void main(String[] args) {
		divisibleByThree(new int[] { 1, 2, 3, 4, 5, 6, 7, 9 });

	}

	public static void divisibleByThree(int[] array) {
		int count = 0;
		for (int element : array) {
			if (element % 3 == 0) {
				count++;
			}
		}
		System.out.println("Amount of elements in array which are divisible by 3: " + count);
	}

}

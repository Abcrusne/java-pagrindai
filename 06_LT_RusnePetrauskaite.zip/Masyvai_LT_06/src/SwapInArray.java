
public class SwapInArray {
	public static void main(String[] args) {
		swaping(new int[] { 1, 2, 3, 4, 5 }, 0, 4);
	}

	public static void swaping(int[] array, int m, int k) {
//		for printing given array
		int index = 0;
		while (index < array.length) {
			System.out.println(array[index]);
			index++;
		}
//		for swaping m with k
		System.out.println("");
//		create temporary array
		int temp = array[m];
		array[m] = array[k];
		array[k] = temp;

		System.out.println("");
		index = 0;
		while (index < array.length) {
			System.out.println(array[index]);
			index++;
		}
	}

}

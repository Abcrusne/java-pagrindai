
//insert new value at before position in array and print new array
// create new array insert from old array values till position, 
//at position insert new value, else insert rest of elements
import java.util.Arrays;

public class InsertNewElement {
	public static int[] insert(int[] array, int newValue, int position) {
		int[] newArray = new int[array.length + 1];
		for (int i = 0; i < array.length + 1; i++) {
			if (i < position - 1) {
				newArray[i] = array[i];
			} else if (i == position - 1) {
				newArray[i] = newValue;
			} else {
				newArray[i] = array[i - 1];
			}
		}
		return newArray;

	}

	public static void main(String[] args) {
		int[] array = new int[] { 1, 2, 3, 4, 5 };
		System.out.println("Original array: " + Arrays.toString(array));
		insert(array, 1, 2);
		int[] insert = insert(array, 1, 2);
		System.out.println("Inserted new value in array: " + Arrays.toString(insert));
	}
}

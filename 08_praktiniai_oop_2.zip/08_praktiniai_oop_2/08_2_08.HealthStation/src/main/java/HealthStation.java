
public class HealthStation {


    public int weigh(Person person) {
        // return the weight of the person passed as the parameter
        return -1;
    }

}


public class PaprastaPreke extends Parduotuve {

	protected double kaina;

	public PaprastaPreke(String prekesVardas, int kiekis) {
		super(prekesVardas, kiekis);

	}

//kaina su mokesciais
	public double getKaina() {
		return kaina * kiekis;
	}

	public void setKaina(double kaina) {
		this.kaina = kaina;
	}

	// kainos paskaiciavimas neto (be mokesciu 21%)
	public double getKainaNeto() {
		return (0.79 * kaina) * kiekis;
	}

	// kaina Sveicarijos frankais
	public double getKainaFrankais() {
		return (1.07 * kaina) * kiekis;
	}

	// kainos paskaiciavimas neto (be mokesciu 21%) Sceicarijos Frankais
	public double getKainaNetoFrankais() {
		return (0.79 * kaina * 1.07) * kiekis;
	}
}

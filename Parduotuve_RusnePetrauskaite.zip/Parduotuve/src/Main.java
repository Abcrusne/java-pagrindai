import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		PaprastaPreke p1 = new PaprastaPreke("preke", 1);
		p1.setKaina(2);
		System.out.println("Prekes tipas? ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		if (input.equals("Vaistas")) {
			System.out.println("Pavadinimas? ");
			String pavadinimas = scanner.nextLine();
			System.out.println("Kiekis? ");
			int kiekis = Integer.parseInt(scanner.nextLine());
			System.out.println("Kaina? ");
			double kaina = Double.parseDouble(scanner.nextLine());
			Vaistas v1 = new Vaistas(pavadinimas, kiekis);
			v1.setKaina(kaina);
			System.out.println("Vaisto kaina: " + v1.getKaina() + " \n Vaisto pavadinimas: " + v1.getPrekesVardas()
					+ " \nVaisto kiekis: " + v1.getKiekis() + "\n Kaina su mokesciais Frankais: "
					+ v1.getKainaFrankais() + "\n Kaina be mokesciu: " + v1.getKainaNeto()
					+ " \nKaina be mokesciu Frankais: " + v1.getKainaNetoFrankais());
		} else if (input.equals("Paprasta Preke")) {
			System.out.println("Pavadinimas? ");
			String pavadinimas = scanner.nextLine();
			System.out.println("Kiekis? ");
			int kiekis = Integer.parseInt(scanner.nextLine());
			System.out.println("Kaina? ");
			double kaina = Double.parseDouble(scanner.nextLine());
			PaprastaPreke pp1 = new PaprastaPreke(pavadinimas, kiekis);
			pp1.setKaina(kaina);
			System.out.println("Prekes kaina: " + pp1.getKaina() + " \n Prekes pavadinimas: " + pp1.getPrekesVardas()
					+ " \n Prekes kiekis: " + pp1.getKiekis() + " \n Kaina su mokesciais Frankais: "
					+ pp1.getKainaFrankais() + " \n Kaina be mokesciu: " + pp1.getKainaNeto()
					+ " \n Kaina be mokesciu Frankais: " + pp1.getKainaNetoFrankais());
		} else if (input.equals("Alkoholis")) {
			System.out.println("Pavadinimas? ");
			String pavadinimas = scanner.nextLine();
			System.out.println("Kiekis? ");
			int kiekis = Integer.parseInt(scanner.nextLine());
			System.out.println("Kaina? ");
			double kaina = Double.parseDouble(scanner.nextLine());
			System.out.println("Alkoholio turis? ");
			double alkTuris = Double.parseDouble(scanner.nextLine());
			AlkGerimas al1 = new AlkGerimas(pavadinimas, kiekis);
			al1.setKaina(kaina);
			al1.setAlkTuris(alkTuris);
			System.out.println("Prekes kaina: " + al1.getKaina() + "\n Prekes pavadinimas: " + al1.getPrekesVardas()
					+ " \n Prekes kiekis: " + al1.getKiekis() + "\n Kaina su mokesciais Frankais: "
					+ al1.getKainaFrankais() + " \n Kaina be mokesciu: " + al1.getKainaNeto()
					+ " \nKaina be mokesciu Frankais: " + al1.getKainaNetoFrankais());
		} else if (input.equals("Vynas")) {
			System.out.println("Pavadinimas? ");
			String pavadinimas = scanner.nextLine();
			System.out.println("Kiekis? ");
			int kiekis = Integer.parseInt(scanner.nextLine());
			System.out.println("Kaina? ");
			double kaina = Double.parseDouble(scanner.nextLine());
			Vynas vy1 = new Vynas(pavadinimas, kiekis);
			System.out.println("Alkoholio turis? ");
			double alkTuris = Double.parseDouble(scanner.nextLine());
			vy1.setKaina(kaina);
			vy1.setAlkTuris(alkTuris);
			System.out.println("Prekes kaina: " + vy1.getKaina() + " \n Prekes pavadinimas: " + vy1.getPrekesVardas()
					+ " \n Prekes kiekis: " + vy1.getKiekis() + " \n Kaina su mokesciais Frankais: "
					+ vy1.getKainaFrankais() + " \n Kaina be mokesciu: " + vy1.getKainaNeto()
					+ " \n Kaina be mokesciu Frankais: " + vy1.getKainaNetoFrankais());
		}
		scanner.close();
	}
}


public class Parduotuve {

	private String prekesVardas;
	protected int kiekis;

	public Parduotuve(String prekesVardas, int kaina) {

		this.prekesVardas = prekesVardas;
		this.kiekis = kaina;
	}

	public String getPrekesVardas() {
		return prekesVardas;
	}

	public int getKiekis() {
		return kiekis;
	}

	public void setPrekesVardas(String prekesVardas) {
		this.prekesVardas = prekesVardas;
	}

	public void setKiekis(int kiekis) {
		this.kiekis = kiekis;
	}

}

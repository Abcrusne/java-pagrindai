
public class Box1<T extends Comparable<T>> {
	private T t1, t2;

	private boolean locked;

	public Box1() {
	}

	public Box1(T t1, T t2) {

		this.t1 = t1;
		this.t2 = t2;
	}

	public T getT1() {
		if (isLocked()) {
			throw new java.lang.RuntimeException("Meta klaida");
		}
		if (t1.compareTo(t2) < 0) {
			return t1;
		}
		return t2;

	}

	private boolean isLocked() {
		return false;
	}

	private boolean lock() {
		return true;
	}

	private boolean unlock() {
		return true;
	}

	public T getT2() {
		if (isLocked()) {
			throw new java.lang.RuntimeException("Meta klaida");
		}
		if (t1.compareTo(t2) < 0) {
			return t2;
		}
		return t1;
	}

	public void setT1(T t1) {
		this.t1 = t1;
	}

	public void setT2(T t2) {
		this.t2 = t2;
	}

	@Override
	public String toString() {
		return "Box1 [t1=" + t1 + ", t2=" + t2 + "]";
	}

}

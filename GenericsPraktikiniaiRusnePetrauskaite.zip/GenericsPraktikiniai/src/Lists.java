import java.util.List;

public class Lists {

	public static <T> T lastElement(T[] array) {
		return array[array.length - 1];
	}

	public static <T> T lastElement(List<T> lists) {
		return lists.get(lists.size() - 1);
	}

//	public static void main(String[] args) {
//
//		ArrayList wordlist = new ArrayList();
//
//		wordlist.add("b");
//		wordlist.add("e");
//		wordlist.add("f");
//		wordlist.add("a");
//
//		lastElement(wordlist);
//	}
//
//	Integer[] intArray = { 1, 2, 3 };
//	String[] strArray = { "a", "b", "c" };
//	lastElement(intArray);
//	lastElement(strArray);
//	}
}

//public class List<T> {
// private List<T> list;
//  private T list;
//
//
//	public List() {
//		this.list = list;
//	}
//
//	public T getList() {
//		return list;
//	}
//
//	public void setList(T list) {
//		this.list = list;
//	}

//	void showType() {
//	System.out.println(list.getClass().getName());
//}
//
//	public static void main(String[] args) {
//		
//	}
//	

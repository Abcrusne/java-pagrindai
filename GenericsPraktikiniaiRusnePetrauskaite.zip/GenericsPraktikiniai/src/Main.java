import java.util.ArrayList;
import java.util.List;

public class Main {

//	Box<String> twoNames = new Box<>("John");
//		

	public static void main(String[] args) {
		List<String> wordList = new ArrayList<>();
		wordList.add("b");
		String lastWord = Lists.lastElement(wordList);

//		ArrayList wordlist = new ArrayList();
//

//		wordlist.add("e");
//		wordlist.add("f");
//		wordlist.add("a");
//
//	lastElement(wordlist);
		Box1<String> twoNames = new Box1<>("John", "Jane");
//		List<String> twoNames = Arrays.asList("a", "b");
//
//		Box1<String, String> twoNames = new Box1<>("John", "Jane");
		System.out.printf("twoNames = %s.%n", twoNames);
		String name1 = twoNames.getT1();
		String name2 = twoNames.getT2();
//		System.out.println(name1);
//		System.out.println(name2);
//
		Box1<Integer> twoNums = new Box1<>(8, 5);
		System.out.printf("twoNums=%s.%n", twoNums);
		Integer num1 = twoNums.getT1();
		Integer num2 = twoNums.getT2();
		System.out.println(num1);
//		System.out.println(num2);

	}
}
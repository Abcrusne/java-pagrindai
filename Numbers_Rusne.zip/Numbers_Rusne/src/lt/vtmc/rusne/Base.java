package lt.vtmc.rusne;

import lt.itakademija.exam.Exercises;
import lt.itakademija.exam.test.BaseTest;

public class Base extends BaseTest {

	@Override
	protected Exercises createExercises() {

		return new ExcerciseImpl();
	}

}

package lt.vtmc.rusne;

import lt.itakademija.exam.IntegerGenerator;
import lt.itakademija.exam.NumberFilter;

public class Decorator implements IntegerGenerator {

	private IntegerGenerator integerGenerator;
	private NumberFilter filter;

	public Decorator(IntegerGenerator integerGenerator, NumberFilter filter) {
		super();
		this.integerGenerator = integerGenerator;
		this.filter = filter;
	}

	@Override
	public Integer getNext() {
		Integer number = integerGenerator.getNext();
		while (number != null && filter.accept(number) == false) {
			number = integerGenerator.getNext();
		}
		return number;
	}
}

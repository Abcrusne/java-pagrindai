package lt.vtmc.rusne;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import lt.itakademija.exam.Exercises;
import lt.itakademija.exam.IntegerGenerator;
import lt.itakademija.exam.NumberFilter;

public class ExcerciseImpl implements Exercises {

	List<Integer> list = new ArrayList<>();

	@Override
	public List<Integer> computeNumbersUpTo(int number) {
		List<Integer> list = new ArrayList<>();

		for (int i = 1; i < number; i++) {
			list.add(i);
		}
		return list;
	}

	@Override
	public int computeSumOfNumbers(int number) {
		int sum = 0;
		for (int i = 0; i <= number; i++) {
			sum += i;
		}
		return sum;
	}

	@Override
	public int computeSumOfNumbers(int number, NumberFilter filter) {
		int sum = 0;
		for (int i = 0; i <= number; i++) {
			if (filter.accept(i)) {
				sum += i;
			}
		}
		return sum;
	}

	public static <T> List<T> getListFromIterator(Iterator<T> iterator) {

		// Create an empty list
		List<T> list = new ArrayList<>();

		// Add each element of iterator to the List
		iterator.forEachRemaining(list::add);

		// Return the List
		return list;
	}

	@Override
	public List<Integer> consume(Iterator<Integer> it) {

		List<Integer> iterator = getListFromIterator(it);

		return iterator;
	}

	@Override
	public Map<Integer, Integer> countOccurrences(List<Integer> numbers) {
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>();
		for (int number : numbers) {
			if (hm.containsKey(number)) {
				hm.put(number, hm.get(number) + 1);
			} else {
				hm.put(number, 1);
			}
		}
		return hm;
	}

	@Override
	public IntegerGenerator createFilteredIntegerGenerator(IntegerGenerator generator, NumberFilter filter) {
		IntegerGenerator newGener = new Decorator(generator, filter);
		return newGener;
	}

	@Override
	public IntegerGenerator createIntegerGenerator(int from, int to) {
		IntegerGeneratorImpl generator = new IntegerGeneratorImpl(from, to);
		return generator;
	}

	@Override
	public Integer findLargest(List<Integer> numbers) {
		return Collections.max(numbers);
	}

	@Override
	public Integer findSmallest(List<Integer> numbers) {
		return Collections.min(numbers);

	}

	@Override
	public boolean isEqual(Object lhs, Object rhs) {
		if (lhs.equals(rhs)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean isSameObject(Object lhs, Object rhs) {
		if (lhs.equals(rhs)) {
			return true;
		} else {
			return false;
		}
	}

}

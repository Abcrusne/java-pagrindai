package lt.vtmc.rusne;

import java.util.ArrayList;
import java.util.List;

import lt.itakademija.exam.IntegerGenerator;

public class IntegerGeneratorImpl implements IntegerGenerator {

	private int from;
	private int to;
	private int index;
	private List<Integer> list = new ArrayList<>();
	// private NumberFilter filter;
	// Decorator dec;

//	public IntegerGeneratorImpl(NumberFilter filter) {
//		this.filter = filter;
//	}
//	public IntegerGeneratorImpl(Decorator dec) {
//		this.dec = dec;
//	}

	public IntegerGeneratorImpl(int from, int to) {
		super();
		this.from = from;
		this.to = to;
//		this.index = 0;
		for (int i = from - 1; i <= to; i++) {
			list.add(i);
		}
	}

	@Override
	public Integer getNext() {
		index++;
		int a = 0;
		if (index < list.size()) {
			a = list.get(index);
		} else {
			return null;
		}
		return a;

	}

}

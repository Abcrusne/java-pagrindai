package lt.vtmc.rusne;

import lt.vtvpmc.BaseNewsServiceTest;
import lt.vtvpmc.NewsService;

public class BaseNewsService extends BaseNewsServiceTest {

	@Override
	protected NewsService getNewsService() {

		return new NewsServiveImplementation();
	}

//	public void articlesWithHeadingsContainingSwearWordsAreNotPresent() {
//	}
//
//	public void articlesContainingSwearWordsInTheirBriefsAreMasked() {
//	}
}

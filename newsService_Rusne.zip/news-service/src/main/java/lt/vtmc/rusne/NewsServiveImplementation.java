package lt.vtmc.rusne;

import java.util.ArrayList;
import java.util.List;

import lt.vtvpmc.Article;
import lt.vtvpmc.NewsService;
import lt.vtvpmc.NewsServiceImpl;

public class NewsServiveImplementation implements NewsService {

	// NewsServiceImpl articles;
	List<Article> articles = new ArrayList<Article>();
	// List<Article> childrenArticles = new ArrayList<Article>();

	private String s1 = "rupūs miltai";
	private String s2 = "velniai rautų";
	private String s3 = "velnias";
	private String s4 = "velniais";

	public List<Article> replaceBriefToSafe(List<Article> articles) {
		List<Article> replacedArticles = new ArrayList<Article>();
		for (Article article : articles) {
			String replac1 = article.getBrief().replace(s1, "***");
			String replac2 = replac1.replace(s2, "***");
			String replac3 = replac2.replace(s3, "***");
			String replac4 = replac3.replace(s4, "***");
			replacedArticles.add(new ArticleImpl(article.getHeading(), replac4));
		}
		return replacedArticles;
	}

	public boolean isHeadingSafe(String heading) {
		if (heading.toLowerCase().contains(s1) || heading.toLowerCase().contains(s2)
				|| heading.toLowerCase().contains(s3) || heading.toLowerCase().contains(s4)) {
			return false;
		}
		return true;
	}

	public List<Article> getArticles() {

		List<Article> childrenArticles = new ArrayList<Article>();
		List<Article> articles = NewsServiceImpl.articles;

		for (Article article : articles) {
			if (isHeadingSafe(article.getHeading())) {
				childrenArticles.add(article);
			}
		}
		return replaceBriefToSafe(childrenArticles);
	}
}
//
//			List<Article> childrenArticles = new ArrayList<Article>();
//List<Article> articles = NewsServiceImpl.articles;
//for (Article article : articles) {
//if (heading.toLowerCase().contains(s1) || heading.toLowerCase().contains(s2)
//		|| heading.toLowerCase().contains(s3) || heading.toLowerCase().contains(s4)) {
// return null;
//{
//				else if (article.getBrief().contains(s1)) {
//					String replac1 = article.getBrief().replace(s1, "***");
//					
//				} else if (article.getBrief().contains(s2)) {
//					String replac2 = replac1.replace(s2, "***");
//				
//				} else if (article.getBrief().contains(s3)) {
//					String replac3 = replac2.replace(s3, "***");
//				
//				} else if (article.getBrief().contains(s4)) {
//					String replac4 = replac3.replace(s4, "***");
//					
//				} else {
//					return childrenArticles;
//				}childrenArticles.add(new ArticleImpl(article.getHeading(), replac4));
//			}
//
//		}
//		return childrenArticles;

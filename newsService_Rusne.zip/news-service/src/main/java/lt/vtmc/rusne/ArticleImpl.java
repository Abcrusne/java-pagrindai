package lt.vtmc.rusne;

import lt.vtvpmc.Article;

public class ArticleImpl implements Article {

	private String brief;
	private String heading;

	public ArticleImpl(String heading, String brief) {
		this.heading = heading;
		this.brief = brief;
	}

	public String getBrief() {

		return this.brief;
	}

	public String getHeading() {

		return this.heading;
	}

}

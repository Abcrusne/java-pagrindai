
public class Main {
	public static void main(String[] args) {
		Employee e1 = new Employee(1, "John", "Johnoson", 900);
		System.out.println(e1.toString());
		e1.setSalary(1000);
		System.out.println("Setted salary: " + e1.getSalary());
		e1.raiseSalary(2);
		System.out.println("Raised salary: " + e1.getSalary());
		System.out.println("Annual salary: " + e1.getAnnualSalary());
		System.out.println(e1.toString());
		System.out.println("Name: " + e1.getName());

		Employee e2 = new Employee(2, "Anna", "Annan", 1002);
		System.out.println(e2.toString());
		e2.raiseSalary(2);
		System.out.println("Raised salary: " + e2.getSalary());

	}
}

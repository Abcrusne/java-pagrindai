
public class Main {
	public static void main(String[] args) {
		Circle c1 = new Circle(5.0);
		System.out.println(c1.toString());
//		System.out.println("The circle has radius of " + c1.getRadius() + " and area of " + c1.getArea());
		Circle c2 = new Circle(1.2);
		System.out.println(c2.toString());
		System.out.println(c2);
		System.out.println("Operator '+' invokes toString() too: " + c2);
//		System.out.println("The circle has radius of " + c2.getRadius() + " and area of " + c2.getArea());
		Circle c3 = new Circle(4.5, "green");
		System.out
				.println("The circle has radius of " + c3.getRadius() + " and area of " + c3.getArea() + c3.getColor());
		Circle c4 = new Circle();
		c4.setRadius(5.0);
		System.out.println("Radius is : " + c4.getRadius());
		c4.setColor("black");
		System.out.println("Color is: " + c4.getColor());
	}
}

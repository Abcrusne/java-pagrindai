
public class Main {
	public static void main(String[] args) {
		Account a1 = new Account("id1", "Petras", 100);
		System.out.println(a1.toString());
		a1.credit(500);
		System.out.println(a1.getName() + " balance after credit: " + a1.getBalance());
		a1.debit(300);
		System.out.println(a1.getName() + " balance after debit: " + a1.getBalance());
		System.out.println(a1.toString());
		Account a2 = new Account("id2", "Mantas", 50);
		System.out.println(a2.toString());
		a1.transferTo(a2, 100);
		System.out.println(a1.getName() + " balance after transfer to " + a2.getName() + " " + a1.getBalance());
		System.out.println(a2.getName() + " balance aftre transfer from " + a1.getName() + " " + a2.getBalance());
		System.out.println(a1.toString());
		System.out.println(a2.toString());
	}
}

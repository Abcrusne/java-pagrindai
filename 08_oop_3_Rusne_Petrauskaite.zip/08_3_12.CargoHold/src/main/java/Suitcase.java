import java.util.ArrayList;

public class Suitcase {

	private ArrayList<Item> items;
	private int count;
	private int maxWeight;
	private int totalWeight;

	public Suitcase(int maxWeight) {

		this.maxWeight = maxWeight;
		this.count = 0;
		this.totalWeight = 0;
		this.items = new ArrayList();
	}

	public void addItem(Item item) {
		if (item.getWeight() + count <= maxWeight) {
			count = count + item.getWeight();
			this.items.add(item);
		}
	}

	public void printItems() {
		for (Item elements : items) {
			System.out.println(elements.getName() + " (" + elements.getWeight() + " kg)");
		}

	}

	public int totalWeight() {
		for (Item elements : items) {
			totalWeight = totalWeight + elements.getWeight();
		}
		return totalWeight;
	}

	public Item heaviestItem() {
		if (items.isEmpty()) {
			return null;
		}
//		newItem value is the first object on the list
		Item newItem = this.items.get(0);
		for (Item elements : items) {
			if (newItem.getWeight() < elements.getWeight()) {
				newItem = elements;
			}
		}
		return newItem;
	}

	public String toString() {
		if (items.isEmpty()) {
			return "no items (" + count + " kg)";
		} else if (this.items.size() == 1) {
			return this.items.size() + " item (" + count + " kg)";
		} else {
			return this.items.size() + " items (" + count + " kg)";
		}
	}
}

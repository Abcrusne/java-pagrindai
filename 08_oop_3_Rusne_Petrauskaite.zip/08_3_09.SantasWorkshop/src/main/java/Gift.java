
public class Gift {
	private String name;
	private int weight;

	public Gift(String name, int weight) {
		super();
		this.name = name;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public int getWeight() {
		return weight;
	}

	@Override
	public String toString() {
		return name + "(" + weight + " kg)";
	}
}

package lt.vtmc.rusn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import lt.vtvpmc.sheep.Sheep;
import lt.vtvpmc.sheep.SheepColor;
import lt.vtvpmc.sheep.SheepIterator;

public class SheepIterImpl implements SheepIterator {
	Sheep sheep;
	SheepColor sheepColor;
	List<Sheep> sheeps = new ArrayList<>();

	private int numberOfSheepToGenerate;

	public SheepIterImpl(int numberOfSheepToGenerate) {
		super();
		this.numberOfSheepToGenerate = numberOfSheepToGenerate;
	}

	@Override
	public boolean hasNext() {
		Iterator<Sheep> iterator = sheeps.iterator();
		while (iterator.hasNext()) {
			iterator.next();
			sheepColor.getDeclaringClass();
			return true;
		}
		return false;
	}

	@Override
	public Sheep next() {
		Iterator<Sheep> iterator = sheeps.iterator();
		if (sheep.getColor().equals(sheepColor.BLACK)) {
		}
		return iterator.next();

	}

}

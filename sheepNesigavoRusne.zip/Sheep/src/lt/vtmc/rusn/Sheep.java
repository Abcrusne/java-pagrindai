package lt.vtmc.rusn;

import lt.vtvpmc.sheep.AbstractSheepIteratorTest;
import lt.vtvpmc.sheep.SheepIterator;

public class Sheep extends AbstractSheepIteratorTest {

	@Override
	public SheepIterator getSheepIterator(int numberOfSheepToGenerate) {
		// TODO Auto-generated method stub
		return new SheepIterImpl(numberOfSheepToGenerate);
	}

}

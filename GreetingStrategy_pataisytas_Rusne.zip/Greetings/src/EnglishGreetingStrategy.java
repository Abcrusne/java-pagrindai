
public class EnglishGreetingStrategy implements GreeterLanguageStrategy {

	@Override
	public String getGreetingString() {
		return String.format("Hello, ");
	}

}

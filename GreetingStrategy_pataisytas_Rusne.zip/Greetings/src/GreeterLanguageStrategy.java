
interface GreeterLanguageStrategy {

	public String getGreetingString();

}

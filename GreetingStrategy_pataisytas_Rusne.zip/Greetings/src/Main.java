
public class Main {
	public static void main(String[] args) {

		Greeter lt1 = new Greeter(new LithuaniaGreeterStrategy(), new SymbolDot());
		lt1.greet("Rasa");

		Greeter en1 = new Greeter(new EnglishGreetingStrategy(), new SymbolExclamation());
		en1.greet("Gabriel");

		Greeter en2 = new Greeter(new EnglishGreetingStrategy(), new SymbolExclamationThree());
		en2.greet("Alex");

	}
}

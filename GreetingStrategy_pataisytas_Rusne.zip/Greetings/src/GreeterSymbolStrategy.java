
public interface GreeterSymbolStrategy {

	public String getSymbolString();

}

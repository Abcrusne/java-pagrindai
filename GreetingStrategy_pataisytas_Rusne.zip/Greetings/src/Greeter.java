
public class Greeter {

	private GreeterLanguageStrategy greeterLanguageStrategy;
	private GreeterSymbolStrategy greeterSymbolStrategy;

	public Greeter(GreeterLanguageStrategy greeterLanguageStrategy, GreeterSymbolStrategy greeterSymbolStrategy) {
		this.greeterLanguageStrategy = greeterLanguageStrategy;
		this.greeterSymbolStrategy = greeterSymbolStrategy;
	}

	public GreeterLanguageStrategy getGreeterLanguageStrategy() {
		return greeterLanguageStrategy;
	}

	public void greet(String name) {
		System.out.println(greeterLanguageStrategy.getGreetingString() + name +  greeterSymbolStrategy.getSymbolString());

	}

}

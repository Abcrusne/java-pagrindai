
public class SymbolDot implements GreeterSymbolStrategy {

	public String getSymbolString() {
		return ".";
	}

}

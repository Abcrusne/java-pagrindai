
public class SymbolExclamation implements GreeterSymbolStrategy {

	public String getSymbolString() {
		return "!";
	}

}

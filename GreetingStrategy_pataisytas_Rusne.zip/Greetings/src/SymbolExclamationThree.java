
public class SymbolExclamationThree implements GreeterSymbolStrategy {

	public String getSymbolString() {
		return "!!!";
	}

}

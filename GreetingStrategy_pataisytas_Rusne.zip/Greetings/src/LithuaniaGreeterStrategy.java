
public class LithuaniaGreeterStrategy implements GreeterLanguageStrategy {

	@Override
	public String getGreetingString() {

		return "Labas, ";
	}

}


public class Checkerboard {
	public static void main(String[] args) {
		printChecker(7, 7);
		System.out.println();
		printCheckerStars(7, 7);
		System.out.println();
		printStars(7);
		System.out.println();
		printDots(7);
	}

	public static void printChecker(int row, int col) {
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= col; j++) {
				if ((i % 2) == (j % 2)) {
					System.out.print("#");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	public static void printCheckerStars(int row, int col) {
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j <= col; j++) {
				if ((i % 2) == (j % 2)) {
					System.out.print("# *");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	public static void printStars(int row) {
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < row - i; j++) {
				System.out.print("*");
			}
			System.out.println();

		}
	}

	public static void printDots(int row) {
		for (int i = 0; i <= row; i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(".");
			}
			System.out.println();
		}
	}
}

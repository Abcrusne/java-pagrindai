
public class NumbersTriangle {
	public static void main(String[] args) {
		number(7);
		numberTriangle(8);
		numberRight(6);
	}

	public static void number(int row) {
		for (int i = 0; i <= row; i++) {
			for (int col = 1; col <= i; col++) {
				System.out.print(col + " ");
			}
			System.out.println();
		}
	}

//	public static void printSpaces(int row) {
//		for (int i = 0; i < row; i++) {
//			for (int col = 0; col >= row - i - 1; col++) {
//				System.out.print("0");
//			}
//			System.out.println();
//		}
//	}

	public static void numberTriangle(int row) {
		for (int i = 0; i <= row; i++) {
			for (int col = 1; col <= row - i; col++) {
				System.out.print("z");
			}
			for (int j = 0; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
	}

	public static void numberRight(int row) {
		for (int i = 0; i <= row; i++) {
			for (int col = 2 * (row - i); col >= 0; col--) {
				System.out.print("0");
			}
			for (int col = 1; col <= i; col++) {
				System.out.print(col + " ");
			}
			System.out.println();
		}
	}
}


public class EvenNumbers {
	public static void main(String[] args) {
		int number;
		// print main table
		for (int i = 1; i < 10; i++) {
			for (int j = 1; j < 10; j++) {
				number = i * j;
				System.out.print(" " + number);
				if (number < 10) {
					System.out.print("  ");
				} else if (number < 100) {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}


public class Patterns {
	public static void main(String[] args) {
		Rectangle(8, 6);
		System.out.println();
		Zet(7);

	}

	public static void Rectangle(int height, int width) {
		for (int i = 1; i <= height; i++) {
			for (int j = 1; j <= width; j++) {
				if (i == 1 || i == height || j == 1 || j == width)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();

		}
	}

	public static void Zet(int width) {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < width; j++) {
				if (i == 0 || i == width - 1 || j == width - 1 - i) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}

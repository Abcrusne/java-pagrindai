import java.util.Scanner;

public class DecimalToOctal {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Give a positive number: ");
		int number = Integer.parseInt(scan.nextLine());
		int[] octalNumber = new int[1000]; // array for storying binary array
		int i = 0;
		// counting for binary array
//		 story remainder in binary array
		while (number > 0) {
			octalNumber[i] = number % 8;
			number = number / 8;
			i++;
		}
//		 print binary array in reverse
		for (int j = i - 1; j >= 0; j--)
			System.out.println(octalNumber[j]);

	}
}

import java.util.Random;
import java.util.Scanner;

public class PigGame {
	public static void main(String[] args) {

		Scanner read = new Scanner(System.in);
		Random random = new Random();
		int userScore = 0;
		int computerScore = 0;
		int computer20 = 0;
		boolean play = true;
		int roll = 0;
		String response;

		do {
			System.out.println("Your turn: ");
			play = true;
			do {
				roll = 1 + random.nextInt(6);
				System.out.println("You rolled " + roll);

				if (roll == 1) {
					System.out.println("Your score: " + userScore + ". Computer's score: " + computerScore);
					play = false;
				} else {
					userScore += roll;
					System.out.println("Your score: " + userScore + ". Computer's score: " + computerScore);
					play = true;
					if (userScore >= 100) {
						play = false;
					} else {
						System.out.println("Enter 'r' to roll again or 'h' to hold.");
						response = read.next();
						if (response.equals("h")) {
							play = false;
						}
					}
				}
			} while (play);

			if (userScore < 100) {
				System.out.println("Computer's turn");
				computer20 = 0;
				play = true;
				do {
					roll = 1 + random.nextInt(6);
					System.out.println("Computer rolled " + roll);
					if (roll == 1) {
						System.out.println("Your score: " + userScore + ". Computer's score: " + computerScore);
						play = false;
					} else {
						computerScore += roll;
						computer20 += roll;
						System.out.println("Your score: " + userScore + ". Computer's score: " + computerScore);
						play = true;
						if (computerScore >= 20) {
							System.out.println("Computer's score >=20.");
							play = false;
						}
						if (computerScore >= 100) {
							play = false;
						}

					}
				} while (play && computer20 < 20);
			}
			System.out.println();
		} while (userScore < 100 && computer20 < 100);
		if (userScore >= 100) {
			System.out.println("You are the winner");
		} else {
			System.out.println("Computer is the winner.");
		}

		read.close();

	}
}

import java.util.Random;
import java.util.Scanner;

public class gameScissorRockPaper {
	public static void main(String[] args) {
		int userScore = 0;
		int computerScore = 0;
		while (true) {
			Scanner scan = new Scanner(System.in);
			System.out.print("Scissor (0), Paper (1), Rock (2)?: ");
			int choice = Integer.parseInt(scan.nextLine());
			Random random = new Random();
			int computer = random.nextInt(3);
			int scissor = 0;
			int paper = 1;
			int rock = 2;
			if (computer == scissor) {
				if (choice == scissor) {
					System.out.println("The computer is  scissor. You are scissor. It is a draw.");
				} else if (choice == paper) {
					System.out.println("The computer is scissor. You are paper. Computer won.");
					computerScore++;
				} else if (choice == rock) {
					System.out.println("The computer is scissor. You are rock. You won.");
					userScore++;
				}
			} else if (computer == paper) {
				if (choice == scissor) {
					System.out.println("The computer is paper. You are scissor. You won.");
					userScore++;
				} else if (choice == paper) {
					System.out.println("The computer is paper. You are paper. It is a draw.");
				} else if (choice == rock) {
					System.out.println("The computer is paper. You are rock. Computer won.");
					computerScore++;
				}
			} else if (computer == rock) {
				if (choice == scissor) {
					System.out.println("The computer is rock. You are scissor. Computer won. ");
					computerScore++;
				} else if (choice == paper) {
					System.out.println("The computer is rock. You are paper. You won.");
				} else if (choice == rock) {
					System.out.println("The computer is rock. You are rock.It is a draw.");
					userScore++;
				}
			}
			if (userScore == 3 && computerScore < 3) {
				System.out.println("You won 3 times.");
				break;
			}
			if (computerScore == 3) {
				System.out.println("Computer won 3 times.");
				break;
			}
		}
	}
}


public class Leapyear {
	public static void main(String[] args) {

		LeapYears(2020, 2120);
	}

	public static void LeapYears(int first, int last) {
		for (int i = first; i <= last; i++) {
			int l = i % 4;
			if (l == 0) {
				System.out.print(i + " ");
			}
		}
	}
}

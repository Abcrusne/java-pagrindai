import java.util.Scanner;

public class PalindromeInteger {
	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		System.out.println("Give a number: ");
		int number = Integer.parseInt(read.nextLine());
		int result = reverse(number);
		if (isPalindrome(number)) {
			System.out.println(number + " is a Palindrome.");
		} else {
			System.out.println(number + " is not a Palindrome.");
		}
	}

	public static int reverse(int number) {
		int reversed = 0;
		while (number != 0) {
			int digit = number % 10;
			reversed = reversed * 10 + digit;
			number = number / 10;
		}
		return reversed;
	}

	public static boolean isPalindrome(int number) {
		int result = reverse(number);
		if (result == number) {
			return true;
		} else {
			return false;
		}
	}
}
// sitas irgi galimas, arba virsuj iskart isPalindrome metode po true
//arba false sout, bet tada virsuj nerasyt if'o, bet isprintins ir boolean ats 
// t.y dar papildomai true arba false, o ne tik pvz 
//"number + is (not) a palindrome."

//		boolean palindrome = false;
//		while (number != 0) {
//			if (number == result) {
//				palindrome = true;
//				System.out.println(number + " is Palindrome.");
//			} else {
//				palindrome = false;
//				System.out.println(number + " is not Palindrome.");
//			}
//			break;
//		}
//		return palindrome;

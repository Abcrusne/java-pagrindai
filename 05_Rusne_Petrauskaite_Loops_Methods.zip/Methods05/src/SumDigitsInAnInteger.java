import java.util.Scanner;

public class SumDigitsInAnInteger {

	public static int sum(int number) {
		int sum = 0;
		while (number != 0) {
			sum = sum + number % 10;
			number = number / 10;
		}
		return sum;

	}

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		System.out.println("Give a number: ");
		int number = Integer.parseInt(read.nextLine());
		int result = sum(number);
		System.out.println(result);
	}
}

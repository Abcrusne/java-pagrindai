package lt.vtmc.praktikinis16Rusne;

import java.util.logging.Logger;

public class Vaistas extends Parduotuve {

	private static final Logger LOG = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	protected double kaina;

	public Vaistas(String prekesVardas, int kiekis) {
		super(prekesVardas, kiekis);
	}

	// kaina su mokesciais
	public double getKaina(double kaina) {
		if (kaina > 0 && kiekis > 0) {
			return kaina * kiekis;
		} else {
			LOG.info("IllegealArgumentException cost and quantity must be positive");
			return kaina * kiekis;
		}
	}

	public void setKaina(double kaina) {
		this.kaina = kaina;
	}

	// kainos paskaiciavimas neto (be mokesciu 9%)
	public double getKainaNeto(double kaina) {
		return (0.91 * kaina) * kiekis;
	}

	// kaina Sveicarijos frankais
	public double getKainaFrankais(double kaina) {
		return (1.07 * kaina) * kiekis;
	}

	// kainos paskaiciavimas neto (be mokesciu 9%) Sceicarijos Frankais
	public double getKainaNetoFrankais(double kaina) {
		return (0.91 * kaina * 1.07) * kiekis;
	}
}

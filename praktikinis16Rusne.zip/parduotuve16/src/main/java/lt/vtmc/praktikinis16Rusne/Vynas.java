package lt.vtmc.praktikinis16Rusne;

import java.util.logging.Logger;

public class Vynas extends Parduotuve {
	private static final Logger LOG = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private double kaina;
	protected double alkTuris;

	public Vynas(String prekesVardas, int kiekis) {
		super(prekesVardas, kiekis);
	}

	public double getAlkTuris() {
		return alkTuris;
	}

	public void setAlkTuris(double alkTuris) {
		this.alkTuris = alkTuris;
	}

	// kaina su mokesciais
	public double getKaina(double kaina) {
		if (kaina > 0 && kiekis > 0) {
			return kaina * kiekis;
		} else {
			LOG.info("IllegealArgumentException cost and quantity must be positive");
			return kaina * kiekis;
		}
	}

	public void setKaina(double kaina) {
		this.kaina = kaina;
	}

	// kainos paskaiciavimas neto (be mokesciu 21%) ir akcizo litrui 0.28e jei
	// alk turis < 8.5% ir 0.72e jei > 8.5%
	public double getKainaNeto(double kaina) {
		if (this.alkTuris < 8.5) {
			return ((0.79 * kaina) * kiekis) - (kiekis * 0.28);
		} else {
			return ((0.79 * kaina) * kiekis) - (kiekis * 0.72);
		}
	}

	// kaina Sveicarijos frankais
	public double getKainaFrankais(double kaina) {
		return (1.07 * kaina) * kiekis;
	}

	// kainos paskaiciavimas neto (be mokesciu) Sceicarijos Frankais
	public double getKainaNetoFrankais(double kaina) {
		if (this.alkTuris < 15) {
			return ((0.79 * kaina * 1.07) * kiekis) - (kiekis * 0.28);
		} else {
			return ((0.79 * kaina) * kiekis * 1.07) - (kiekis * 0.72);
		}
	}

}

package lt.vtmc.rusne;

import java.util.ArrayList;
import java.util.List;

import com.eisgroup.javaexam.beercollector.Beer;
import com.eisgroup.javaexam.beercollector.BeerBottle;
import com.eisgroup.javaexam.beercollector.BeerCan;
import com.eisgroup.javaexam.beercollector.BeerCollector;
import com.eisgroup.javaexam.beercollector.IllegalBeerPackageException;

public class BeerCollectorImpl implements BeerCollector {

	List<Beer> beers = new ArrayList<Beer>();

	public void addBeerToCollection(Beer beer) throws IllegalBeerPackageException {
		if (beer == null || beer.getBrand() == null || beer.getBrand().isEmpty() || beer.getVolume() <= 0
				|| beer instanceof BeerBottle) {
			throw new IllegalBeerPackageException();
		} else if (!beers.contains(beer) && beer instanceof BeerCan) {
			beers.add(beer);
		}

	}

	public double getTotalVolume() {

		return beers.stream().mapToDouble(volume -> volume.getVolume()).reduce(0, (acc, element) -> acc + element);
	}

}

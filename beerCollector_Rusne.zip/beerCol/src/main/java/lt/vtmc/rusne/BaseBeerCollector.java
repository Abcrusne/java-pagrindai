package lt.vtmc.rusne;

import com.eisgroup.javaexam.beercollector.BeerCollector;
import com.eisgroup.javaexam.beercollector.tests.BaseBeerCollectorTest;

public class BaseBeerCollector extends BaseBeerCollectorTest {

	@Override
	protected BeerCollector createBeerCollector() {

		return new BeerCollectorImpl();
	}

}

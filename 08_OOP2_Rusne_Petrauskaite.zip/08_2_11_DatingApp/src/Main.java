
public class Main {
	public static void main(String[] args) {
		SimpleDate date = new SimpleDate(13, 2, 2015);
		date.advance(7);

		System.out.println("Now: " + date);
		System.out.println("After one week: " + date);
//		System.out.println("Friday of the examined week is " + date.toString());
//		SimpleDate newDate = date.afterNumberOfDays(7);
//		int week = 1;
//		while (week <= 7) {
//			System.out.println("Friday after " + week + " week is " + newDate);
//			newDate = newDate.afterNumberOfDays(7);
//			week = week + 1;
//
//		}
//		System.out.println(date.afterNumberOfDays(60));
	}
}


public class Main {

	public static void main(String[] args) {
		// write experimental main programs here
		PaymentCard petesCard = new PaymentCard(10);
		PaymentTerminal unicafe = new PaymentTerminal();
		System.out.println(unicafe);

//		double change = unicafe.eatAffordably(10);
//		System.out.println("remaining change: " + change);
//
		PaymentCard annesCard = new PaymentCard(2);
		System.out.println("balance " + annesCard.balance());
		boolean wasSuccessful = unicafe.eatHeartily(annesCard);
		System.out.println("there was enough money: " + wasSuccessful);
		unicafe.addMoneyToCard(annesCard, 100);

		wasSuccessful = unicafe.eatHeartily(annesCard);
		System.out.println("there was enough money: " + wasSuccessful);
		System.out.println("balance " + annesCard.balance());
		System.out.println(unicafe);

//
//		boolean wasSuccessful = unicafe.eatHeartily(annesCard);
//		System.out.println("there was enough money: " + wasSuccessful);
//		wasSuccessful = unicafe.eatHeartily(annesCard);
//		System.out.println("there was enough money: " + wasSuccessful);
//		wasSuccessful = unicafe.eatAffordably(annesCard);
//		System.out.println("there was enough money: " + wasSuccessful);

//		System.out.println(unicafe);

//		change = unicafe.eatAffordably(5);
//		System.out.println("remaining change: " + change);
//
//		change = unicafe.eatHeartily(4.3);
//		System.out.println("remaining change: " + change);
//
//		System.out.println(unicafe);
//
//		System.out.println("money " + petesCard.balance());
//		boolean wasSuccessful = petesCard.takeMoney(8);
//		System.out.println("seccessfully withdrew: " + wasSuccessful);
//		System.out.println("money " + petesCard.balance());
//		wasSuccessful = petesCard.takeMoney(4);
//		System.out.println("seccessfully withdrew: " + wasSuccessful);
//		System.out.println("money " + petesCard.balance());

	}
}

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.eisgroup.javaexam.library.Book;
import com.eisgroup.javaexam.library.Library;

public class LibraryTestKitas implements Library {

	private List<Book> items = new ArrayList<>();

	public LibraryTestKitas() {
	}

	@Override
	public Collection<Book> findByAuthor(String arg0) {
		ArrayList<Book> collections = new ArrayList<>();
		for (Book elements : items) {
			if (elements.getAuthor().equals(arg0)) {
				collections.add(elements);
			}
		}
		return collections;

	}

	@Override
	public Book findByTitle(String arg0) {
		// find by title get book name if book name equals to string

		for (Book elements : items) {
			if (elements.getTitle().equals(arg0)) {
				return elements;
			}
			return elements;
		}
		return null;
	}

	@Override
	public Collection<Book> getBooksSortedByPageCount() {

		Collections.sort(items, new Klase());

		return items;

	}

	@Override
	public int getNumberOfBooks() {
		return items.size();
	}

	@Override
	public void takeABook(Book arg0) {
		if (!items.contains(arg0)) {
			this.items.add(arg0);
		}
	}

}

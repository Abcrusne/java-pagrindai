import com.eisgroup.javaexam.library.Library;
import com.eisgroup.javaexam.library.test.BaseLibraryTest;

//si class reikalinga nes turi tuos testus, ji testuoja Library metodus
//Library yra interface

public class LibraryTest extends BaseLibraryTest {

	@Override
//	savo biblioteka grazinam kuri implementuoja

	protected Library getLibrary() {

		return new LibraryTestKitas();
	}

}

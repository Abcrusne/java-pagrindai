
import java.util.Comparator;

import com.eisgroup.javaexam.library.Book;

public class Klase implements Comparator<Book> {

	public int compare(Book o1, Book o2) {
		if (o1.getPageCount() == o2.getPageCount()) {
			return 0;
		} else if (o1.getPageCount() > o2.getPageCount()) {
			return 1;
		} else {
			return -1;
		}
	}
}

import ibank.Bank;
import ibank.BaseBankTest;

public class Basebank extends BaseBankTest {

	@Override
	protected Bank createBank() {

		return new myAccount();
	}

}

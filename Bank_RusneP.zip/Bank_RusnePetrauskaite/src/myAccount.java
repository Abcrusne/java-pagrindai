import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.UUID;

import ibank.Account;
import ibank.Bank;

public class myAccount implements Account, Bank {

	private String accountNumber = UUID.randomUUID().toString();
	private String accountOwner;
	private BigDecimal balance;
	private BigDecimal creditLimit;

	Collection<Account> list = new ArrayList<>();
	Collection<String> holders = new ArrayList<>();

	public myAccount(String accountNumber, String accountOwner, BigDecimal balance) {
		this.accountNumber = accountNumber;
		this.accountOwner = accountOwner;
		this.balance = new BigDecimal(0);
	}

	public myAccount() {
		this.balance = new BigDecimal(0);
	}

	public myAccount(String accountOwner) {
		this.balance = new BigDecimal(0);
		this.accountOwner = accountOwner;
	}

	@Override
	public boolean deposit(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) > 0) {
			balance = balance.add(amount);
			return true;
		}
		return false;
		// balance.add(amount) != null;
	}

	@Override
	public BigDecimal getBalance() {

		return this.balance;
	}

	@Override
	public String getHolderName() {

		return this.accountOwner;
	}

	@Override
	public String getNumber() {

		return this.accountNumber;
	}

	@Override
	public boolean withdraw(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) > 0
				&& balance.add(creditLimit).subtract(amount).compareTo(BigDecimal.ZERO) >= 0) {
			balance = balance.subtract(amount);
			return true;
		}
		return false;
		// balance.subtract(amount) != null;
	}

	@Override
	public void closeAccount(Account account) {
		// list.remove(account);
		list.remove(account.getBalance());
		list.clear();
		// account.getBalance().subtract(getBalance());
	}

	@Override
	public Account getAccountByHolderName(String name) {
		for (Account acc : list) {
			if (acc.getHolderName().equals(name)) {
				return acc;
			}
		}

		return null;
	}

	@Override
	public Account getAccountByNumber(String number) {
		for (Account acc : list) {
			if (acc.getNumber().equals(number)) {
				return acc;
			}
		}
		return null;
	}

	@Override
	public Collection<Account> getAllAccounts() {

		return list;
	}

	@Override
	public int getNumberOfAccounts() {

		return list.size();
	}

	@Override
	public BigDecimal getTotalReserves() {

		return list.stream().map(balance -> balance.getBalance()).reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	@Override
	public Account openCreditAccount(String name, BigDecimal limit) {
		if (!(name.isEmpty()) && name != null && limit != null && (!holders.contains(name))) {

			Credit credit = new Credit(name, limit);
			list.add(credit);
			holders.add(name);
			return credit;
		}

		else {
			return null;
		}
	}

	@Override
	public Account openDebitAccount(String name) {
		if (!(name.isEmpty()) && name != null && (!holders.contains(name))) {
			Debit debit = new Debit(name);
			list.add(debit);
			holders.add(name);
			return debit;
		} else {
			return null;
		}
	}

}
// returns debit Account if creation succeeded, null otherwise
//        we check if bank doesn't have opened accounts, or if if the client doesn't have one already, and create one
//		if (list.isEmpty()) {
//			Account debitAccount = new myAccount(name);
//			list.add(debitAccount);
//			return debitAccount;
//		}
////        When bank has opened accounts.
////        There can be only one account per client. so we check if the client has one already
//		Iterator<Account> iterator = list.iterator();
//		while (iterator.hasNext()) {
//			Account account = (Account) iterator.next();
//			if (!account.getHolderName().equals(name)) {
//				Account debitAccount = new myAccount(name);
//				list.add(debitAccount);
//				return debitAccount;
//			}
//		}
//		return null;

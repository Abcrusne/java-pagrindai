import java.math.BigDecimal;
import java.util.UUID;

import ibank.Account;

public class Debit implements Account {

	private String accountOwner;
	private BigDecimal balance;
	private String accountNumber = UUID.randomUUID().toString();

	public Debit(String accountOwner) {
		super();
		this.accountOwner = accountOwner;
		this.balance = new BigDecimal(0);

	}

	@Override
	public boolean deposit(BigDecimal amount) {

		if (amount.compareTo(BigDecimal.ZERO) > 0) {
			balance = balance.add(amount);
			return true;
		}
		return false;
	}

	@Override
	public BigDecimal getBalance() {

		return this.balance;
	}

	@Override
	public String getHolderName() {

		return this.accountOwner;
	}

	@Override
	public String getNumber() {

		return this.accountNumber;
	}

	@Override
	public boolean withdraw(BigDecimal amount) {
		if (amount.compareTo(BigDecimal.ZERO) > 0) {
			balance = balance.subtract(amount);
			return true;
		}
		return false;
	}
}

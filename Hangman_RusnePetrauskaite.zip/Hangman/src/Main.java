import java.util.Scanner;

public class Main {

	private static String[] words = { "polymorphism", "inheritance", "encapsulation" };
	private static int missed = 0;
	private static String word = words[(int) (Math.random() * words.length)];
	private static String asterisk = new String(new char[word.length()]).replace("\0", "*");

	public static void main(String[] args) {

		Scanner reader = new Scanner(System.in);
		while (asterisk.contains("*")) {
			System.out.println("(Guess) Enter a letter in word ");
			System.out.println(asterisk);
			String guess = reader.next();
			hang(guess);
		}
		reader.close();
	}

	public static void hang(String guess) {
		String newAsterisk = "";
		for (int i = 0; i < word.length(); i++) {
			if (word.charAt(i) == guess.charAt(0)) {
				newAsterisk += guess.charAt(0);
			} else if (asterisk.charAt(i) != '*') {
				newAsterisk += word.charAt(i);
			} else {
				newAsterisk += "*";
			}
		}
		if (asterisk.equals(newAsterisk)) {
			missed++;
		} else {
			asterisk = newAsterisk;
		}
		if (asterisk.equals(word)) {
			System.out.println("The word is " + word + ". You missed " + missed + " time/s");
			System.out.println("Do you want guess another word? Enter y or n");
			Scanner reader = new Scanner(System.in);
			String input = reader.next();
		}

	}

}

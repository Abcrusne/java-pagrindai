
public class Greeter {

	private GreeterLanguageStrategy greeterLanguageStrategy;
	String name;

	public Greeter() {

	}

	public GreeterLanguageStrategy getGreeterLanguageStrategy() {
		return greeterLanguageStrategy;
	}

	public String getName() {
		return name;
	}

	public void setGreeterLanguageStrategy(GreeterLanguageStrategy greeterLanguageStrategy) {
		this.greeterLanguageStrategy = greeterLanguageStrategy;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void getGreetingString(String name) {
		greeterLanguageStrategy.getGreetingString(name);

	}

}

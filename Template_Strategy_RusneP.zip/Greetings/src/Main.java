
public class Main {
	public static void main(String[] args) {

		Greeter lt = new Greeter();

		lt.setGreeterLanguageStrategy(new LithuanianGreetingStrategy());
		lt.getGreetingString("Petras");

		lt.setGreeterLanguageStrategy(new LithuanianGreetingStrategyOne());
		lt.getGreetingString("Petras2");

		lt.setGreeterLanguageStrategy(new LithuanianGreetingStrategyTwo());
		lt.getGreetingString("Petras3");

		System.out.println("----");

		Greeter en = new Greeter();

		en.setGreeterLanguageStrategy(new EnglishGreetingStrategy());
		en.getGreetingString("Peter");

		en.setGreeterLanguageStrategy(new EnglishGreetingStrategyOne());
		en.getGreetingString("Peter1");

		en.setGreeterLanguageStrategy(new EnglishGreetingStrategyTwo());
		en.getGreetingString("Peter2");

	}
}

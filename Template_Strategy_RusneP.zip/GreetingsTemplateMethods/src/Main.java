
public class Main {

	public static void main(String[] args) {
		Greeter lt = new LithuanianGreeter("Jonas", "Jonaitis");
		Greeter en = new EnglishGreeter("John", "Johns");
		lt.greet();
		System.out.println("------");
		en.greet();

	}

}


public class LithuanianGreeter extends Greeter {

	public LithuanianGreeter(String firstName, String lastName) {
		super(firstName, lastName);

	}

	@Override
	protected void getGreetingString() {
		System.out.println("Labas, " + getFirstName() + " " + getLastName());

	}

}

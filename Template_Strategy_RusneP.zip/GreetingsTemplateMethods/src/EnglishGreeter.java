
public class EnglishGreeter extends Greeter {

	public EnglishGreeter(String firstName, String lastName) {
		super(firstName, lastName);

	}

	@Override
	protected void getGreetingString() {
		System.out.println("Hello, " + getFirstName() + " " + getLastName());

	}

}

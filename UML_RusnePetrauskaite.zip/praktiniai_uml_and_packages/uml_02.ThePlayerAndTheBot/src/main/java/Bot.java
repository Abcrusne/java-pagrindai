
public class Bot extends Player {

	public Bot(String name) {
		super(name);

	}

	public void play() {

	}

	public void addMove(String move) {

	}

}

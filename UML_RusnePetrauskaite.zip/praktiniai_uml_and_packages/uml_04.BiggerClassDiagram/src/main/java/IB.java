
public interface IB {

}

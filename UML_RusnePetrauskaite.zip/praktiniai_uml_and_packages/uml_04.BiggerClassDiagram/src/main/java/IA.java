
public interface IA {

}


public class D implements IA {

	private IA ia;
}

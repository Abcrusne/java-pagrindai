
public class B extends A implements IB {

}

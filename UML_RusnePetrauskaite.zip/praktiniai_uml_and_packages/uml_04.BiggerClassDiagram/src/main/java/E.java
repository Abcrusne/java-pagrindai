import java.util.ArrayList;

public class E extends C {

	private ArrayList<C> c;
}

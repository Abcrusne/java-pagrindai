
public interface IC {

}

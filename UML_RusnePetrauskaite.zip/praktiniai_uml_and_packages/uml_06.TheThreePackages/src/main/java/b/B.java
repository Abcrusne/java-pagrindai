package b;

public class B {

}

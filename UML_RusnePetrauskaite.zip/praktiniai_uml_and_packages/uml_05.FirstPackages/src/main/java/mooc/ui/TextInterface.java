package mooc.ui;

public class TextInterface implements UserInterface {

	@Override
	public void update() {
		System.out.println("Updating UI");

	}

}

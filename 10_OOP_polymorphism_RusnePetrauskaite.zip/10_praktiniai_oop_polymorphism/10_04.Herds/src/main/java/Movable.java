

public interface Movable {

    void move(int dx, int dy);
}


public interface NoiseCapable {

	void makeNoise();

}

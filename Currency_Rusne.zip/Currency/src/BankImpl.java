import java.util.ArrayList;
import java.util.List;

import lt.itakademija.exam.Account;
import lt.itakademija.exam.AccountCreateException;
import lt.itakademija.exam.Bank;
import lt.itakademija.exam.Currency;
import lt.itakademija.exam.CurrencyConverter;
import lt.itakademija.exam.Customer;
import lt.itakademija.exam.CustomerCreateException;
import lt.itakademija.exam.InsufficientFundsException;
import lt.itakademija.exam.Money;
import lt.itakademija.exam.Operation;
import lt.itakademija.exam.PersonCode;
import lt.itakademija.exam.PersonName;
import lt.itakademija.exam.SequenceGenerator;

public class BankImpl implements Bank {

	private CurrencyConverter currencyConverter;
	private List<Customer> customers = new ArrayList<>();
	private SequenceGenerator customerSequance = new SequenceGenerator();
	private SequenceGenerator accountSequance = new SequenceGenerator();
	private SequenceGenerator operationSequance = new SequenceGenerator();

	public BankImpl(CurrencyConverter currencyConverter) {
		this.currencyConverter = currencyConverter;
	}

	@Override
	public Customer createCustomer(PersonCode personCode, PersonName personName) {
		// tureti list'a kur saugosim Customers, patikrinti ar neegzistuoja toks
		// Customer jau musu list'e
		// patikrinti ar parametrai Customer'io nera null'ai
		// jei ne sukurti nauja Customer ir ji prideti i list'a ir ji grazinti
		if (personCode == null || personName == null) {
			throw new NullPointerException();
		}

		for (Customer customer : customers) {
			if (customer.getPersonCode().equals(personCode)) {
				throw new CustomerCreateException("This person Code already exist.");
			}

		}
		Customer customer = new Customer(customerSequance.getNext(), personCode, personName);
		customers.add(customer);

		return customer;
	}

	@Override
	public Account createAccount(Customer customer, Currency currency) {
		// kad sukurt Account Customer'iui visu pirma jis turi egzistuoti
		if (customer == null || currency == null) {
			throw new NullPointerException();
		}
		if (!customers.contains(customer)) {
			throw new AccountCreateException("There is no Customer with this description.");
		}
		// Account(Long id, Customer customer, Currency currency, Money balance)
		// Money irgi klase
		Account account = new Account(accountSequance.getNext(), customer, currency, new Money(0.0d));
		// Created account is registered with a customer
		// that is passed in as a parameter using Customer.addAccount(Account).
		customer.addAccount(account);
		return account;

	}

	@Override
	public Operation transferMoney(Account debitAccount, Account creditAccount, Money debitAmount) {
		if (debitAccount.getBalance().isLessThan(debitAmount)) {
			throw new InsufficientFundsException("failed");
		}
		// is debitAccount paimam debitAmount ir nustatom nauja DebitAccount
		// balance
		debitAccount.setBalance(debitAccount.getBalance().substract(debitAmount));
		// konvertuoti pinigus
		Money creditAmount = currencyConverter.convert(debitAccount.getCurrency(), creditAccount.getCurrency(),
				debitAmount);
		// i creditAccount pridedam pinigus
		creditAccount.setBalance(creditAccount.getBalance().add(creditAmount));

		return new Operation(operationSequance.getNext(), debitAccount, creditAccount, debitAmount);
	}

	@Override
	public Money getBalance(Currency currency) {
		Money balance = new Money(0.0);
		for (Customer customer : customers) {
			for (Account account : customer.getAccounts()) {
				if (account.getCurrency().equals(currency)) {
					balance = balance.add(account.getBalance());
				} else {
					balance = balance
							.add(currencyConverter.convert(account.getCurrency(), currency, account.getBalance()));
				}
			}
		}
		return balance;
	}

}

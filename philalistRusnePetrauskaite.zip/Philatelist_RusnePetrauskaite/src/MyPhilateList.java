import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import philatelist.Philatelist;
import philatelist.PostStamp;

public class MyPhilateList implements Philatelist {

	private List<PostStamp> list = new ArrayList<>();

	@Override
	public void addToCollection(PostStamp post) {

		if (post == null || post.getName() == null || post.getName().isEmpty()) {
			throw new IllegalArgumentException("PostStamp is empty" + post);
		} else if (!list.contains(post)) {
			list.add(post);
		}

	}

	@Override
	public double getAveragePostStampPrice() {
		// TODO Auto-generated method stub

		return list.stream().mapToDouble(price -> price.getMarketPrice()).average().getAsDouble();

	}

	@Override
	public int getNumberOfPostStampsInCollection() {
		return (int) list.size();

	}

	@Override
	public PostStamp getTheMostExpensivePostStamByMarketValue() {

		PostStamp posts = Collections.max(list, Comparator.comparing(s -> s.getMarketPrice()));
		return posts;
	}

}

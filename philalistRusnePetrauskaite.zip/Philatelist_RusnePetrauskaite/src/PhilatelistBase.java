import philatelist.Philatelist;
import philatelist.PhilatelistBaseTest;

public class PhilatelistBase extends PhilatelistBaseTest {

	@Override
	protected Philatelist getPhilatelist() {

		return new MyPhilateList();
	}

}

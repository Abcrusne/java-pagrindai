import java.util.Arrays;

public class InsertionSort {
	public static void main(String[] args) {
		int[] array = { 9, 2, 4, 1, 5 };
		insertionSort(array);

	}

	public static void insertionSort(int[] array) {
		for (int i = 0; i < array.length - 1; i++) {
//			take the next element
			int element = array[i];
			int j = i - 1;
//			find a suitable position to
//			insert and shift elements to right
			while (j >= 0 && array[j] > element) {
				array[j + 1] = array[j];
				j--;
			}
			array[j + 1] = element;
			System.out.println(Arrays.toString(array));

		}
//		System.out.println(Arrays.toString(array));
	}
}

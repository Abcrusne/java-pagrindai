
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Lambda1 {

	public void runExercises() {
		System.out.println("JDK 8 Lambdas and Streams MOOC Lesson 1");
		System.out.println("Running exercise 1 solution...");
		exercise1();
		System.out.println("Running exercise 2 solution...");
		exercise2();
		System.out.println("Running exercise 3 solution...");
		exercise3();
		System.out.println("Running exercise 4 solution...");
		exercise4();
//		    System.out.println("Running exercise 5 solution...");
//		    exercise5();
	}

//	* Create a string that consists of the first letter of each word in the list
	private void exercise1() {
		List<String> list = Arrays.asList("alpha", "bravo", "charlie", "delta", "echo", "foxtrot");
//		kazka priimama kaip parametra
		StringBuilder result = new StringBuilder();

		list.forEach(s -> result.append(s.charAt(0)));
		System.out.println(result);

//		list.forEach(s -> System.out.print(s.charAt(0)));
//		System.out.println();

	}

	/**
	 * Exercise 2
	 *
	 * Remove the words that have odd lengths from the list.
	 */
	private void exercise2() {
		List<String> list = new ArrayList<>(
				Arrays.asList("aa", "alpha", "bravo", "charlie", "delta", "echo", "foxtrot"));

//		StringBuilder result = new StringBuilder();
//		list.forEach(s -> result.append(list.remove(s.length() % 2 != 0)));
//		System.out.println(result);
		list.removeIf(s -> s.length() % 2 != 0);
		list.forEach(s -> System.out.println(s));
	}

	/**
	 * Exercise 3
	 *
	 * Replace every word in the list with its upper case equivalent.
	 */
	private void exercise3() {
		List<String> list = new ArrayList<>(Arrays.asList("alpha", "bravo", "charlie", "delta", "echo", "foxtrot"));
		StringBuilder result = new StringBuilder();
//		list.forEach(s -> s.toUpperCase());

		list.replaceAll(s -> s.toUpperCase());
		list.forEach(s -> System.out.println(s));
	}

	/**
	 * Exercise 4
	 *
	 * Convert every key-value pair of the map into a string and append them all
	 * into a single string, in iteration order.
	 */
	private void exercise4() {
		Map<String, Integer> map = new TreeMap<>();
		map.put("c", 3);
		map.put("b", 2);
		map.put("a", 1);

		StringBuilder result = new StringBuilder();
		map.forEach((key, value) -> result.append(key + value));
		System.out.println(result.toString());

	}

	public static void main(String[] args) {
		Lambda1 lesson = new Lambda1();
		lesson.runExercises();
	}

}

package kd2Rusne;

import lt.vtvpmc.java.imperial.ImperialCube;
import lt.vtvpmc.java.imperial.MetricCube;

public class MetricCubeImpl implements MetricCube {
	private ImperialCube imperialCube;
	private String color;

	public MetricCubeImpl(ImperialCube imperialCube) {
		this.imperialCube = imperialCube;
		this.color = color;
	}

	@Override
	public String getColor() {
		return imperialCube.getColor();
	}

	public String setColor(String color) {
		String oldColor = imperialCube.getColor();
		// oldColor.replace(oldColor, color)

		return oldColor = color;
	}

	@Override
	public double getSideInCentimeters() {
		return (imperialCube.getSideInInches() * 2.54);
	}

	@Override
	public double getVolumeInCentimeters() {

		return Math.pow((imperialCube.getSideInInches() * 2.54), 3);
	}

}

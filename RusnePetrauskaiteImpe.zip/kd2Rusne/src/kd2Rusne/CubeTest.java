package kd2Rusne;

import lt.vtvpmc.java.imperial.AbstractCubeTest;
import lt.vtvpmc.java.imperial.ImperialCube;
import lt.vtvpmc.java.imperial.MetricCube;

public class CubeTest extends AbstractCubeTest {

	@Override
	protected MetricCube adapt(ImperialCube imperialCube) {

		return new MetricCubeImpl(imperialCube);
	}

}

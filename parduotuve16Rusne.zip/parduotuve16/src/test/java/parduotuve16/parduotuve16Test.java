package parduotuve16;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import lt.vtmc.praktikinis16Rusne.PaprastaPreke;
import lt.vtmc.praktikinis16Rusne.Vaistas;

class parduotuve16Test {

	@Test
	void testVaistasKaina() {
		Vaistas vaistas = new Vaistas("Ibuprom", 2);
		assertEquals((4), vaistas.getKaina(2));
	}

	@Test
	void exceptionTesting() {
		PaprastaPreke preke = new PaprastaPreke("Sultys", 1);
		assertEquals((3.16), preke.getKainaNeto(4));

	}
}

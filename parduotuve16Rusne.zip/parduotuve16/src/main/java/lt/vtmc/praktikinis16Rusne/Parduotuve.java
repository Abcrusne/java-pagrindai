package lt.vtmc.praktikinis16Rusne;

/**
 * Abstract class Parduotuve with 4 abstract methods
 */
public abstract class Parduotuve {

	private String prekesVardas;
	protected int kiekis;

	public Parduotuve(String prekesVardas, int kiekis) {

		this.prekesVardas = prekesVardas;
		this.kiekis = kiekis;
	}

	/**
	 * Constructor
	 */
	public String getPrekesVardas() {
		return prekesVardas;
	}

	public int getKiekis() {
		return kiekis;
	}

	public void setPrekesVardas(String prekesVardas) {
		this.prekesVardas = prekesVardas;
	}

	public void setKiekis(int kiekis) {
		this.kiekis = kiekis;
	}

	/**
	 * Specifies and return Cost of goods Cost of one item is get from user input
	 */
	public abstract double getKaina(double kaina);

	/**
	 * Specifies and return Cost of goods without taxes
	 */
	public abstract double getKainaNeto(double kaina);

	/**
	 * Specifies and return converted Cost of goods in Swiss franc
	 */
	public abstract double getKainaFrankais(double kaina);

	/**
	 * Specifies and return converted Cost of goods in Swiss franc without taxes
	 */
	public abstract double getKainaNetoFrankais(double kaina);

}

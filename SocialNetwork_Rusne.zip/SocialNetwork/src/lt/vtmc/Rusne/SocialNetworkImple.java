package lt.vtmc.Rusne;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import lt.infobalt.itakademija.javalang.exam.socialnetwork.Friend;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.FriendNotFoundException;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.SocialNetwork;

public class SocialNetworkImple implements SocialNetwork {

	List<Friend> friends = new ArrayList<>();

	@Override
	public void addFriend(Friend friend) {
		if (friend == null) {
			throw new IllegalArgumentException("Friend cannot be a null");
		} else if (!(friends.contains(friend))) {
			friends.add(friend);
		}
	}

	@Override
	public Collection<Friend> findByCity(String city) {
		if (city == null) {
			throw new IllegalArgumentException("City cannot be empty");
		} else {
			return friends.stream().filter(c -> c.getCity().equals(city)).collect(Collectors.toList());
		}
	}

	@Override
	public Friend findFriend(String firstName, String lastName) throws FriendNotFoundException {
		if (firstName == null || lastName == null) {
			throw new IllegalArgumentException(" Name cannot be empty.");
		}

		for (Friend friend : friends) {
			if (friend.getFirstName().equals(firstName) && friend.getLastName().equals(lastName)) {
				return friend;
			}
		}

		throw new FriendNotFoundException(firstName, lastName);
	}

	@Override
	public int getNumberOfFriends() {

		return friends.size();
	}

	@Override
	public Collection<Friend> getOrderedFriends() {
		Collections.sort(friends, new ComparatorForFriend());

		return friends;

	}

}

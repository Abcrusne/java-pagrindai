package lt.vtmc.Rusne;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.BaseSocialNetworkTest;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.SocialNetwork;

public class BaseSocialNetwork extends BaseSocialNetworkTest {

	@Override
	protected SocialNetwork getSocialNetwork() {

		return new SocialNetworkImple();
	}

}

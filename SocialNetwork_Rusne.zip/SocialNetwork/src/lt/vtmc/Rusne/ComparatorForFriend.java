package lt.vtmc.Rusne;
import java.util.Comparator;

import lt.infobalt.itakademija.javalang.exam.socialnetwork.Friend;

public class ComparatorForFriend implements Comparator<Friend> {

	public int compare(Friend f1, Friend f2) {
		int compare;

		compare = f1.getCity().compareTo(f2.getCity());
		if (compare == 0) {
			compare = f1.getLastName().compareTo(f2.getLastName());
		}
		if (compare == 0) {
			compare = f1.getFirstName().compareTo(f2.getFirstName());
		}
		return compare;

	}

}

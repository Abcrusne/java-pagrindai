package lt.vtmc.Rusne;
import java.util.ArrayList;
import java.util.List;

import lt.infobalt.itakademija.javalang.exam.socialnetwork.SocialNetwork;

public class Main {
	public static void main(String[] args) {
		List<SocialNetwork> fr = new ArrayList<>();

	}
}

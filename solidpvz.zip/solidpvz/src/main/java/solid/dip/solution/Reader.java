package solid.dip.solution;

public interface Reader {

    int read();

}

package solid.dip.solution;

public interface Writer {

    void write(int aChar);

}

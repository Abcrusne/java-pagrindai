package solid.isp.solution;

public interface Swimmer {

    void swim();

}

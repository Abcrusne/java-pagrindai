package solid.isp.solution;

public interface Jumper {

    void jump();

}

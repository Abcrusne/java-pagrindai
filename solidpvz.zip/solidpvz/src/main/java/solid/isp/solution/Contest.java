package solid.isp.solution;

public interface Contest {

    void compete();

}

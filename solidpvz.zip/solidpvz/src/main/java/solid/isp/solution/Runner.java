package solid.isp.solution;

public interface Runner {

    void run();

}

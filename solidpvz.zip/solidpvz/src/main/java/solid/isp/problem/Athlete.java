package solid.isp.problem;

public interface Athlete {

    void swim();

    void run();

    void jump();

}

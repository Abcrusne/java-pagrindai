package solid.isp.problem;

public interface Contest {

    void compete();

}

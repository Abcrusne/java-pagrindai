package solid.ocp.problem;

public interface Shape {

    double area();

}

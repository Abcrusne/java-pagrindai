package solid.ocp.solution;

public interface Shape {

    double area();

    void draw();

}

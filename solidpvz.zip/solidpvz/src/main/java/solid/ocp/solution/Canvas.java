package solid.ocp.solution;

public class Canvas {

    public void draw(Shape shape) {
        shape.draw();
    }

}

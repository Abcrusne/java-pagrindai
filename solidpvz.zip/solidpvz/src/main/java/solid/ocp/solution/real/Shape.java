package solid.ocp.solution.real;

import java.awt.*;

public interface Shape {

    double area();

    void draw(Graphics2D g);

}

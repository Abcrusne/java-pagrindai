package pvz.patterns.templatemethod;

 public class Actor extends Worker {
    @Override
    public void workingProcess() {
        System.out.println(" > I read a scenario");
        System.out.println(" > I get used to role ");
        System.out.println(" > I play a role");
   }
 }

 
 
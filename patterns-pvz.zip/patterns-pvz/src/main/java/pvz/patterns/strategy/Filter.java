package pvz.patterns.strategy;

public interface Filter {
  void apply(String fileName);
}

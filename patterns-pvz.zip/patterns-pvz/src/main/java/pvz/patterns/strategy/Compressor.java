package pvz.patterns.strategy;

public interface Compressor {
//  byte[] compress(byte[] image);
  void compress(String fileName);
}

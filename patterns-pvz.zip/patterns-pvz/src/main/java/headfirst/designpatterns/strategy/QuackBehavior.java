package headfirst.designpatterns.strategy;

public interface QuackBehavior {
	public void quack();
}

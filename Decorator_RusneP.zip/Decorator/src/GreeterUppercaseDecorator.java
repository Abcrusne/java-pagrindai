
public class GreeterUppercaseDecorator implements Greeter {

	private Greeter original;

	public GreeterUppercaseDecorator(Greeter original) {
		this.original = original;

	}

	@Override
	public String greet(String firstName, String lastName) {
		return original.greet(firstName, lastName).toUpperCase();
	}

}

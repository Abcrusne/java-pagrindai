
public class GreeterEnglish implements Greeter {

	@Override
	public String greet(String firstName, String lastName) {
		return "Hello " + firstName + " " + lastName;
	}

}


public class Main {

	public static void main(String[] args) {
		Greeter g1 = new GreeterExclamationMarkDecorator(new GreeterLithuania());
		System.out.println(g1.greet("Rusne", "P"));
		Greeter g2 = new GreeterExclamationMarkDecorator(new GreeterUppercaseDecorator(new GreeterLithuania()));
		System.out.println(g2.greet("Jonas", "Jon"));
	}
}


public class GreeterImpl implements Greeter {

	@Override
	public String greet(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

}

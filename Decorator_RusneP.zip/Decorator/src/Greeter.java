
public interface Greeter {

	public String greet(String firstName, String lastName);
}

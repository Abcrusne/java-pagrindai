import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		Account a1 = new Account(1122, 1000, 1.5, "George");
		a1.deposit(30);
		a1.deposit(40);
		a1.deposit(50);

		a1.withdraw(5);
		a1.withdraw(4);
		a1.withdraw(2);
		System.out.println(a1);
		System.out.println(a1.transaction());
		System.out.println(Arrays.toString((a1.transaction()).toArray()));

//		a1.withdraw(3000);
//		System.out.println(a1);
//		a1.deposit(3000);
//		System.out.println(a1);
//
//		Account a2 = new SavingAccount();
//		a2.setBalance(1000);
//		a2.withdraw(500);
//		System.out.println(a2);
//
//		Account a3 = new CheckingAccount();
//		a3.setBalance(1000);
//		a3.withdraw(1200);
//		System.out.println(a3);

	}
}


public class SavingAccount extends Account {

	public SavingAccount() {

	}

	double overdraftLimit = 0;

	public double withdraw(double amount) {
		if (balance - amount < 0) {
			System.out.println("Amount exceeded balance. It is Savings account.");
		} else {
			balance = balance - amount;
		}
		return balance;

	}

}


public class CheckingAccount extends Account {

	public CheckingAccount() {

	}

	public double withdraw(double amount) {

		balance = balance - amount;

		return balance;
	}

}
package lt.vtmc.rusne;

import lt.itakademija.exam.TruckManager;
import lt.itakademija.exam.test.BaseTest;

public class Base extends BaseTest {

	@Override
	protected TruckManager createTransportManager() {

		return new TruckManagerImpl();
	}

}

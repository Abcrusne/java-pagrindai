package lt.vtmc.rusne;

import java.util.ArrayList;
import java.util.List;

import lt.itakademija.exam.Packet;
import lt.itakademija.exam.Truck;
import lt.itakademija.exam.TruckManager;

public class TruckManagerImpl implements TruckManager {

	List<Truck> trucks = new ArrayList<Truck>();
	List<Packet> packets = new ArrayList<>();

	public void assignTruck(Truck truck, Packet packet) {
		packet.assignTruck(truck);

	}

	public List<Packet> getPackets(String truckId) {
		List<Packet> packetsList = new ArrayList<Packet>();
		for (Packet pack : packets) {
			if (pack.getAssignedTruck().getId().equals(truckId))
				packetsList.add(pack);
		}

		return packetsList;
	}

	public int getTotalTruckCapacity() {

		return trucks.stream().mapToInt(capacity -> capacity.getCapacity()).reduce(0, (acc, element) -> acc + element);
	}

	public Truck getTruckById(String id) {

		for (Truck truck : trucks) {
			if (truck.getId().equals(id)) {
				return truck;
			}
		}
		return null;
	}

	public List<Truck> getTrucks() {

		return trucks;
	}

	public Packet registerPacket(String id, int volume) {
		Packet packet = new Packet(id, volume);
		if (id == null) {
			throw new NullPointerException();
		} else if (id.isEmpty() || volume <= 0) {
			throw new IllegalArgumentException();
		} else if (!packets.contains(packet)) {
			packets.add(packet);
		}
		return packet;
	}

	public Truck registerTruck(String id, int capacity) {
		Truck truck = new Truck(id, capacity);
		if (id == null) {
			throw new NullPointerException();
		} else if (id.isEmpty() || capacity <= 0) {
			throw new IllegalArgumentException();
		} else if (!trucks.contains(truck)) {

			trucks.add(truck);
		}
		return truck;
	}

}

import java.util.ArrayList;
import java.util.List;

public class StringUtils {

	@FunctionalInterface
	public interface Predicate<T> {

		boolean test(T t1);
	}

	public static <T> List<T> allMatches(List<T> list, Predicate<T> pred) {
		List<T> newList = new ArrayList<>();
		for (T element : list) {
			if (pred.test(element)) {
				newList.add(element);
			}
		}
		return newList;

	}

	@FunctionalInterface
	public interface Function<String1, String2> {

		String applyFunction(String s);
	}

//	public interface Function<T1, T2> {
//		<T> T applyFunction(T t1);
//	}

	public static List<String> transformedList(List<String> list, Function<String, String> func) {
		List<String> newList = new ArrayList<>();
		for (String element : list) {

			newList.add(func.applyFunction(element));
		}
		return newList;
	}

//	public static <T> List<T> transformedList(List<T> list, Function<T, T> func) {
//		List<T> newList = new ArrayList<>();
//		for (T element : list) {
//
//			newList.add(func.applyFunction(element));
//		}
//		return newList;
//	}

}

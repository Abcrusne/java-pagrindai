import java.util.Arrays;
import java.util.List;

public class Lambdas3 {

	public static void main(String[] args) {
//		List<String> words = new ArrayList<>();
//		words.add("abc");
//		words.add("def");
//		words.add("ghlklmn");
//		words.add("oprs");

		List<String> words = Arrays.asList("hi", "hello", "good", "bye");
//		List<String> shortWords = StringUtils.allMatches(words, s -> s.length() < 4);
//		System.out.println(shortWords);
//		List<String> wordsWithB = StringUtils.allMatches(words, s -> s.contains("b"));
//		System.out.println(wordsWithB);
//		List<String> evenLengthWords = StringUtils.allMatches(words, s -> (s.length() % 2) == 0);
//		System.out.println(evenLengthWords);

		List<Integer> nums = Arrays.asList(1, 10, 100, 1000, 10000);
		List<Integer> bigNums = StringUtils.allMatches(nums, n -> n > 500);
//
		List<String> excitingWords = StringUtils.transformedList(words, s -> s + "!");
		System.out.println(excitingWords);
		List<String> eyeWords = StringUtils.transformedList(words, s -> s.replace("i", "eye"));
		System.out.println(eyeWords);
		List<String> upperCaseWords = StringUtils.transformedList(words, String::toUpperCase);
		System.out.println(upperCaseWords);
//		List<Integer> wordLengths = StringUtils.transformedList(words, String::length);
	}

	public int length() {

		return 0;
	}

}


public class C extends B {

	public void c() {
		System.out.println("C");
	}
}

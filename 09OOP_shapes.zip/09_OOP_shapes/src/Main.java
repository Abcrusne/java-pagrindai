import java.util.ArrayList;
import java.util.Scanner;

public class Main {

public static void main(String[] args) {
	Shape s1 = new Shape();
	Shape s2 = new Circle();
		
	System.out.println(s1.toString());
	
	Circle c1 = new Circle();
	System.out.println(c1.toString());
	

	Square sq = new Square();
	System.out.println(sq.toString());
	
	Rectangle r1 = new Rectangle();
	System.out.println(r1.toString());
//	create arraylist and insert into it objects
	ArrayList<Shape> objects = new ArrayList<Shape>();
	objects.add(s1);
	objects.add(c1);
	objects.add(sq);
	objects.add(r1);
	
	System.out.println(objects);
	
}

}

package farmsimulator;

public interface Alive {
    void liveHour();
}

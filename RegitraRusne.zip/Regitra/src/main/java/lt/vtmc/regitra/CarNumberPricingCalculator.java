package lt.vtmc.regitra;

public class CarNumberPricingCalculator {

	public Double calculatePrice(String string) {

		return null;
	}

}


public class CarNumberPricingCalculator {

	public double calculatePrice(String number) {
		return 1.0;
	}

}

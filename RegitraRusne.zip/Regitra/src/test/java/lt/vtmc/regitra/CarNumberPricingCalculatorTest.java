package lt.vtmc.regitra;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CarNumberPricingCalculatorTest {
	private CarNumberPricingCalculator priceCalc;

	@BeforeEach
	void initEach() {
		priceCalc = new CarNumberPricingCalculator();
	}

	@Test
	void testAllNumbersAndLettersAreTheSameCost5000() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		assertEquals(new Double(5000.0), priceCalc.calculatePrice("AAA111"));
	}

	@Test
	void testAllNumbersORLettersAreTheSameCost1000() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		assertEquals(new Double(1000.0), priceCalc.calculatePrice("AAA123"));
		assertEquals(new Double(1000.0), priceCalc.calculatePrice("ABC111"));
		assertEquals(new Double(1000.0), priceCalc.calculatePrice("ABC001"));
		assertEquals(new Double(1000.0), priceCalc.calculatePrice("ABC666"));
	}

	@Test
	void testSpecialLettersCost2000() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		assertEquals(new Double(2000.0), priceCalc.calculatePrice("GOD123"));
		assertEquals(new Double(2000.0), priceCalc.calculatePrice("KLR112"));
		assertEquals(new Double(2000.0), priceCalc.calculatePrice("BOS113"));
	}

	@Test
	void testSpecialLettersWithSameNumbersCost7000() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		assertEquals(new Double(7000.0), priceCalc.calculatePrice("GOD111"));
		assertEquals(new Double(7000.0), priceCalc.calculatePrice("KLR111"));
		assertEquals(new Double(7000.0), priceCalc.calculatePrice("BOS555"));
	}

	@Test
	void testNominalNumberCost10000() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("1"));
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("12"));
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("123"));
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("1234"));
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("12345"));
		assertEquals(new Double(10000.0), priceCalc.calculatePrice("123456"));
	}

	@Test
	void exceptionTesting() {
		// CarNumberPricingCalculator priceCalc = new CarNumberPricingCalculator();
		Exception exception = assertThrows(IllegalArgumentException.class,
				() -> priceCalc.calculatePrice("1234567!@#$%^&*()-+?;:"));
		assertEquals("Incorrect plate number format. Must be 1-6 symbols" + " latin letters and number combination",
				exception.getMessage());
		Exception exception1 = assertThrows(IllegalArgumentException.class, () -> priceCalc.calculatePrice("1234567"));
		assertEquals("Incorrect plate number format. Must be 1-6 symbols" + " latin letters and number combination",
				exception1.getMessage());
		Exception exception2 = assertThrows(IllegalArgumentException.class, () -> priceCalc.calculatePrice("!@#$?"));
		assertEquals("Incorrect plate number format. Must be 1-6 symbols" + " latin letters and number combination",
				exception2.getMessage());
	}

}

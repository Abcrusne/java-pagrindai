
public class Credit extends Account {

	public Credit(int id, String name, double balance) {
		super(id, name, balance);

	}

	public double withdraw(double amount) {

		balance = balance - amount;

		return balance;
	}

}

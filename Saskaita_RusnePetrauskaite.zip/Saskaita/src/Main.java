
public class Main {
	public static void main(String[] args) {
		Debet d1 = new Debet(1, "DebetoKortelesVardas", 100);
		d1.withdraw(101);
		System.out.println(d1);
		d1.withdraw(10);
		System.out.println(d1);

		Credit c1 = new Credit(2, "Kreditokortelesvardas", 200);
		c1.withdraw(250);
		System.out.println(c1);

	}
}


public class Debet extends Account {

	public Debet(int id, String name, double balance) {
		super(id, name, balance);
		// TODO Auto-generated constructor stub
	}

	double overdraftLimit = 0;

	public double withdraw(double amount) {
		if (balance - amount < 0) {
			System.out.println("Amount exceeded balance. It is Debet account.");
		} else {
			balance = balance - amount;
		}
		return balance;

	}

}

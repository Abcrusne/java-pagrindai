import itaphones.phone.MobilePhone;
import itaphones.phone.Phone;

public class MobilePhoneAdapter implements Phone {

	MobilePhone mobilePhone;
	String response = "";

	public MobilePhoneAdapter(MobilePhone mobilePhone) {
		this.mobilePhone = mobilePhone;

	}

	public void dial(String number) {
		response = mobilePhone.dial(number);
	}

	public String getReponse() {
		return response;

	}

}

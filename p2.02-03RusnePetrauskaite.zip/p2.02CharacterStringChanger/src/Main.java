public class Main {
	public static void main(String[] args) {
		// Test your program here

		String word = "carrot";
		Change change1 = new Change('a', 'b');
		word = change1.change(word);
		System.out.println(word);
		Change Change2 = new Change('r', 'x');
		word = Change2.change(word);
		System.out.println(word);

		Changer scandiesAway = new Changer();
		scandiesAway.addChange(new Change('A', 'I'));
		scandiesAway.addChange(new Change('!', '?'));
		scandiesAway.addChange(new Change('e', 'a'));
		scandiesAway.addChange(new Change('i', 'u'));
		System.out.println(scandiesAway.change("Architect!"));

	}
}

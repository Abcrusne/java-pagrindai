import java.util.ArrayList;

public class Changer {

	private Change change;
	private ArrayList<Change> changer;

	public Changer() {

		this.changer = new ArrayList<Change>();
	}

	public void addChange(Change change) {
		changer.add(change);
	}

	public String change(String characterString) {

		String changed = characterString;

		for (Change element : changer) {
			changed = element.change(changed);
		}
		return changed;

	}

}

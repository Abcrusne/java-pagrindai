public class Calculator {

	private Reader reader;
	private int count;

	public Calculator() {
		reader = new Reader();
		this.count = 0;
	}

	public void start() {
		while (true) {

			System.out.print("command: ");
			String command = reader.readString();
			if (command.equals("end")) {
				break;
			}
			if (command.equals("sum")) {
				sum();
			} else if (command.equals("difference")) {
				difference();
			} else if (command.equals("product")) {
				product();
			}
		}
		statistics();
	}

	private void sum() {
		this.count++;
		System.out.print("value1: ");
		int input1 = this.reader.readInteger();

		System.out.print("value2: ");
		int input2 = this.reader.readInteger();

		int total = input1 + input2;
		System.out.print("sum of values " + total);

	}

	private void difference() {
		this.count++;
		System.out.print("value1: ");
		int input1 = this.reader.readInteger();

		System.out.print("value2: ");
		int input2 = this.reader.readInteger();

		int total = input1 - input2;
		System.out.print("difference of values " + total);
	}

	private void product() {
		this.count++;
		System.out.print("value1: ");
		int input1 = this.reader.readInteger();

		System.out.print("value2: ");
		int input2 = this.reader.readInteger();

		int total = input1 * input2;
		System.out.print("product of values " + total);
	}

	private void statistics() {

		System.out.print("Calculations done " + this.count);

	}
}
